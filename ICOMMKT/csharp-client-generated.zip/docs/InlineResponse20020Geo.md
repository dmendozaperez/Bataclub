# IO.Swagger.Model.InlineResponse20020Geo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CountryISOCode** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 
**RegionISOCode** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**Zip** | **string** |  | [optional] 
**Coords** | **string** |  | [optional] 
**IP** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

