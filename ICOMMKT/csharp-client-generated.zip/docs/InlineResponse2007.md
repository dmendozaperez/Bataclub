# IO.Swagger.Model.InlineResponse2007
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Templates** | [**List&lt;InlineResponse2007Templates&gt;**](InlineResponse2007Templates.md) |  | [optional] 
**TotalCount** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

