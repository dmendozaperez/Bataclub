# IO.Swagger.Model.InlineResponse20014Details
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeliveryMessage** | **string** |  | [optional] 
**DestinationServer** | **string** |  | [optional] 
**DestinationIP** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

