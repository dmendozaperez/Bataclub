# IO.Swagger.Model.InlineResponse2003Bounces
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **string** |  | 
**Type** | **string** |  | 
**TypeCode** | **int?** |  | 
**Name** | **string** |  | 
**Tag** | **string** |  | 
**MessageID** | **string** |  | 
**ServerID** | **string** |  | 
**Description** | **string** |  | 
**Details** | **string** |  | 
**Email** | **string** |  | 
**From** | **string** |  | 
**BouncedAt** | **string** |  | 
**DumpAvailable** | **bool?** |  | 
**Inactive** | **bool?** |  | 
**CanActivate** | **bool?** |  | 
**Subject** | **string** |  | 
**Content** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

