# IO.Swagger.Model.InlineResponse20031
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_10s** | **int?** |  | [optional] 
**_1s** | **int?** |  | [optional] 
**_20s** | **int?** |  | [optional] 
**_3s** | **int?** |  | [optional] 
**_7s** | **int?** |  | [optional] 
**_8s** | **int?** |  | [optional] 
**Days** | [**List&lt;InlineResponse20031Days&gt;**](InlineResponse20031Days.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

