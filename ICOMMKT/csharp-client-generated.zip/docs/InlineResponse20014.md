# IO.Swagger.Model.InlineResponse20014
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Attachments** | **List&lt;Object&gt;** |  | [optional] 
**Bcc** | **string** |  | [optional] 
**Body** | **string** |  | [optional] 
**Cc** | **string** |  | [optional] 
**From** | **string** |  | [optional] 
**HtmlBody** | **string** |  | [optional] 
**MessageEvents** | [**List&lt;InlineResponse20014MessageEvents&gt;**](InlineResponse20014MessageEvents.md) |  | [optional] 
**MessageID** | **string** |  | [optional] 
**ReceivedAt** | **string** |  | [optional] 
**Recipients** | **List&lt;Object&gt;** |  | [optional] 
**Status** | **string** |  | [optional] 
**Subject** | **string** |  | [optional] 
**Tag** | **string** |  | [optional] 
**TextBody** | **string** |  | [optional] 
**To** | [**List&lt;InlineResponse20013To&gt;**](InlineResponse20013To.md) |  | [optional] 
**TrackLinks** | **string** |  | [optional] 
**TrackOpens** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

