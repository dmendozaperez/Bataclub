# IO.Swagger.Model.InlineResponse20036
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tags** | [**List&lt;InlineResponse20036Tags&gt;**](InlineResponse20036Tags.md) |  | [optional] 
**TotalCount** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

