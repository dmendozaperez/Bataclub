# IO.Swagger.Model.InlineResponse20042
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **int?** |  | [optional] 
**Rule** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

