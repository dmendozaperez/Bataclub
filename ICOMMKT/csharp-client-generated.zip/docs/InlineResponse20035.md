# IO.Swagger.Model.InlineResponse20035
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List&lt;InlineResponse20035Days&gt;**](InlineResponse20035Days.md) |  | [optional] 
**HTML** | **int?** |  | [optional] 
**Text** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

