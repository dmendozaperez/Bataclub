# IO.Swagger.Model.InlineResponse20030
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AppleMail** | **int?** |  | [optional] 
**Days** | [**List&lt;InlineResponse20030Days&gt;**](InlineResponse20030Days.md) |  | [optional] 
**Outlook2010** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

