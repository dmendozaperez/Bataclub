# IO.Swagger.Model.InlineResponse20011SuggestedTemplateModel
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserName** | **string** |  | [optional] 
**Company** | [**List&lt;InlineResponse20011Company&gt;**](InlineResponse20011Company.md) |  | [optional] 
**Person** | [**List&lt;InlineResponse20011Person&gt;**](InlineResponse20011Person.md) |  | [optional] 
**SubjectHeadline** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

