# IO.Swagger.Model.InlineResponse20041
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InboundRules** | [**List&lt;InlineResponse20041InboundRules&gt;**](InlineResponse20041InboundRules.md) |  | [optional] 
**TotalCount** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

