# IO.Swagger.Model.InlineResponse2002Data
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InactiveMails** | **int?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

