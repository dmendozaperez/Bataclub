# IO.Swagger.Model.InlineResponse200Data
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**To** | **string** |  | 
**SubmittedAt** | **string** |  | 
**MessageID** | **string** |  | 
**ErrorCode** | **int?** |  | 
**Message** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

