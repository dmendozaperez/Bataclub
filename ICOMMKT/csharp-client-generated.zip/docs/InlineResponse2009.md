# IO.Swagger.Model.InlineResponse2009
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** |  | [optional] 
**Alias** | **string** |  | [optional] 
**AssociatedServerId** | **string** |  | [optional] 
**HtmlBody** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Subject** | **string** |  | [optional] 
**TemplateId** | **int?** |  | [optional] 
**TextBody** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

