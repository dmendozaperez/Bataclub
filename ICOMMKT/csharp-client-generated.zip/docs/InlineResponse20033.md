# IO.Swagger.Model.InlineResponse20033
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List&lt;InlineResponse20033Days&gt;**](InlineResponse20033Days.md) |  | [optional] 
**GoogleChrome** | **int?** |  | [optional] 
**SafariMobile** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

