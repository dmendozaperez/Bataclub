using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IBouncesAPIApi
    {
        /// <summary>
        /// Activate a bounce Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="bounceid"></param>
        /// <returns>InlineResponse2005</returns>
        InlineResponse2005 ActivateBounce (string contentType, string accept, string xTrxApiKey, int? bounceid);
        /// <summary>
        /// Get bounce dump Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="bounceid"></param>
        /// <returns>InlineResponse2004</returns>
        InlineResponse2004 GetBounceDump (string accept, string xTrxApiKey, int? bounceid);
        /// <summary>
        /// Get a single bounce Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="bounceid">ID of the bounce </param>
        /// <returns>InlineResponse2003</returns>
        InlineResponse2003 GetBounceSingle (string accept, string xTrxApiKey, int? bounceid);
        /// <summary>
        /// Get bounces Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="count">- Number of bounces to return per request. Max 500. </param>
        /// <param name="offset">- Number of bounces to skip. </param>
        /// <param name="type">- Filter by type of bounce. </param>
        /// <param name="inactive">- Filter by emails that were deactivated by ICOMMKT due to the bounce. Set to true or false. If this isn’t specified it will return both active and inactive. </param>
        /// <param name="emailFilter">- Filter by email address. </param>
        /// <param name="tag">- Filter by tag. </param>
        /// <param name="messageID">- Filter by messageID. </param>
        /// <param name="fromdate">- Filter messages starting from the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <param name="todate">- Filter messages up to the date specified (inclusive). e.g. 2014-02-01.    </param>
        /// <returns>InlineResponse2003</returns>
        InlineResponse2003 GetBounces (string accept, string xTrxApiKey, int? count, int? offset, string type, bool? inactive, string emailFilter, string tag, string messageID, string fromdate, string todate);
        /// <summary>
        /// Get an array of tags that have generated bounces for a given server. Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <returns>InlineResponse2006</returns>
        InlineResponse2006 GetTags (string accept, string xTrxApiKey);
        /// <summary>
        /// Get delivery Status Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <returns>InlineResponse2002</returns>
        InlineResponse2002 GetdeliveryStatus (string accept, string xTrxApiKey);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class BouncesAPIApi : IBouncesAPIApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BouncesAPIApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public BouncesAPIApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="BouncesAPIApi"/> class.
        /// </summary>
        /// <returns></returns>
        public BouncesAPIApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Activate a bounce Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param> 
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="bounceid"></param> 
        /// <returns>InlineResponse2005</returns>            
        public InlineResponse2005 ActivateBounce (string contentType, string accept, string xTrxApiKey, int? bounceid)
        {
            
            // verify the required parameter 'contentType' is set
            if (contentType == null) throw new ApiException(400, "Missing required parameter 'contentType' when calling ActivateBounce");
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling ActivateBounce");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling ActivateBounce");
            
            // verify the required parameter 'bounceid' is set
            if (bounceid == null) throw new ApiException(400, "Missing required parameter 'bounceid' when calling ActivateBounce");
            
    
            var path = "/bounces/{bounceid}/activate";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "bounceid" + "}", ApiClient.ParameterToString(bounceid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (contentType != null) headerParams.Add("Content-Type", ApiClient.ParameterToString(contentType)); // header parameter
 if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ActivateBounce: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ActivateBounce: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2005) ApiClient.Deserialize(response.Content, typeof(InlineResponse2005), response.Headers);
        }
    
        /// <summary>
        /// Get bounce dump Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="bounceid"></param> 
        /// <returns>InlineResponse2004</returns>            
        public InlineResponse2004 GetBounceDump (string accept, string xTrxApiKey, int? bounceid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetBounceDump");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetBounceDump");
            
            // verify the required parameter 'bounceid' is set
            if (bounceid == null) throw new ApiException(400, "Missing required parameter 'bounceid' when calling GetBounceDump");
            
    
            var path = "/bounces/{bounceid}/dump";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "bounceid" + "}", ApiClient.ParameterToString(bounceid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBounceDump: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBounceDump: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2004) ApiClient.Deserialize(response.Content, typeof(InlineResponse2004), response.Headers);
        }
    
        /// <summary>
        /// Get a single bounce Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="bounceid">ID of the bounce </param> 
        /// <returns>InlineResponse2003</returns>            
        public InlineResponse2003 GetBounceSingle (string accept, string xTrxApiKey, int? bounceid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetBounceSingle");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetBounceSingle");
            
            // verify the required parameter 'bounceid' is set
            if (bounceid == null) throw new ApiException(400, "Missing required parameter 'bounceid' when calling GetBounceSingle");
            
    
            var path = "/bounces/{bounceid}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "bounceid" + "}", ApiClient.ParameterToString(bounceid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBounceSingle: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBounceSingle: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2003) ApiClient.Deserialize(response.Content, typeof(InlineResponse2003), response.Headers);
        }
    
        /// <summary>
        /// Get bounces Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="count">- Number of bounces to return per request. Max 500. </param> 
        /// <param name="offset">- Number of bounces to skip. </param> 
        /// <param name="type">- Filter by type of bounce. </param> 
        /// <param name="inactive">- Filter by emails that were deactivated by ICOMMKT due to the bounce. Set to true or false. If this isn’t specified it will return both active and inactive. </param> 
        /// <param name="emailFilter">- Filter by email address. </param> 
        /// <param name="tag">- Filter by tag. </param> 
        /// <param name="messageID">- Filter by messageID. </param> 
        /// <param name="fromdate">- Filter messages starting from the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <param name="todate">- Filter messages up to the date specified (inclusive). e.g. 2014-02-01.    </param> 
        /// <returns>InlineResponse2003</returns>            
        public InlineResponse2003 GetBounces (string accept, string xTrxApiKey, int? count, int? offset, string type, bool? inactive, string emailFilter, string tag, string messageID, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetBounces");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetBounces");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetBounces");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetBounces");
            
    
            var path = "/bounces";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
            if (count != null) formParams.Add("count", ApiClient.ParameterToString(count)); // form parameter
if (offset != null) formParams.Add("offset", ApiClient.ParameterToString(offset)); // form parameter
if (type != null) formParams.Add("type", ApiClient.ParameterToString(type)); // form parameter
if (inactive != null) formParams.Add("inactive", ApiClient.ParameterToString(inactive)); // form parameter
if (emailFilter != null) formParams.Add("emailFilter", ApiClient.ParameterToString(emailFilter)); // form parameter
if (tag != null) formParams.Add("tag", ApiClient.ParameterToString(tag)); // form parameter
if (messageID != null) formParams.Add("messageID", ApiClient.ParameterToString(messageID)); // form parameter
if (fromdate != null) formParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // form parameter
if (todate != null) formParams.Add("todate", ApiClient.ParameterToString(todate)); // form parameter
                
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBounces: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBounces: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2003) ApiClient.Deserialize(response.Content, typeof(InlineResponse2003), response.Headers);
        }
    
        /// <summary>
        /// Get an array of tags that have generated bounces for a given server. Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <returns>InlineResponse2006</returns>            
        public InlineResponse2006 GetTags (string accept, string xTrxApiKey)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetTags");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetTags");
            
    
            var path = "/bounces/tags";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTags: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTags: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2006) ApiClient.Deserialize(response.Content, typeof(InlineResponse2006), response.Headers);
        }
    
        /// <summary>
        /// Get delivery Status Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <returns>InlineResponse2002</returns>            
        public InlineResponse2002 GetdeliveryStatus (string accept, string xTrxApiKey)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetdeliveryStatus");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetdeliveryStatus");
            
    
            var path = "/deliverystats";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetdeliveryStatus: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetdeliveryStatus: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2002) ApiClient.Deserialize(response.Content, typeof(InlineResponse2002), response.Headers);
        }
    
    }
}
