using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IStatsAPIApi
    {
        /// <summary>
        /// Get bounce counts (Gets total counts of emails you’ve sent out that have been returned as bounced.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20025</returns>
        InlineResponse20025 GetBounceCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get browser platform usage (Gets an overview of the browser platforms used to open your emails. This is only recorded when Link Tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20034</returns>
        InlineResponse20034 GetBrowserPlatformUsage (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get browser usage (Gets an overview of the browsers used to open links in your emails. This is only recorded when Link Tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20033</returns>
        InlineResponse20033 GetBrowserUsage (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get click counts (Gets total counts of unique links that were clicked.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20032</returns>
        InlineResponse20032 GetClickCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get click location (Gets an overview of which part of the email links were clicked from (HTML or Text). This is only recorded when Link Tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20035</returns>
        InlineResponse20035 GetClickLocation (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get email client usage (Gets an overview of the email clients used to open your emails. This is only recorded when open tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20030</returns>
        InlineResponse20030 GetEmailClientUsage (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get email open counts (Gets total counts of recipients who opened your emails. This is only recorded when open tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20028</returns>
        InlineResponse20028 GetEmailOpenCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get email platform usage (Gets an overview of the platforms used to open your emails. This is only recorded when open tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20029</returns>
        InlineResponse20029 GetEmailPlatformUsage (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get email read times (Gets the length of time that recipients read emails along with counts for each time. This is only recorded when open tracking is enabled for that email. Read time tracking stops at 20 seconds, so any read times above that will appear in the 20s+ field.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20031</returns>
        InlineResponse20031 GetEmailReadTimes (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get outbound overview (Gets a brief overview of statistics for all of your outbound email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20023</returns>
        InlineResponse20023 GetOutboundOverview (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get sent counts (Gets a total count of emails you’ve sent out.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20024</returns>
        InlineResponse20024 GetSentCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get spam complaints (Gets a total count of recipients who have marked your email as spam.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20026</returns>
        InlineResponse20026 GetSpamComplaints (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
        /// <summary>
        /// Get tracked email counts (Gets a total count of emails you’ve sent with open tracking or link tracking enabled.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param>
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20027</returns>
        InlineResponse20027 GetTrackedEmailCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class StatsAPIApi : IStatsAPIApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatsAPIApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public StatsAPIApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="StatsAPIApi"/> class.
        /// </summary>
        /// <returns></returns>
        public StatsAPIApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Get bounce counts (Gets total counts of emails you’ve sent out that have been returned as bounced.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20025</returns>            
        public InlineResponse20025 GetBounceCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetBounceCounts");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetBounceCounts");
            
    
            var path = "/stats/outbound/bounces";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBounceCounts: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBounceCounts: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20025) ApiClient.Deserialize(response.Content, typeof(InlineResponse20025), response.Headers);
        }
    
        /// <summary>
        /// Get browser platform usage (Gets an overview of the browser platforms used to open your emails. This is only recorded when Link Tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20034</returns>            
        public InlineResponse20034 GetBrowserPlatformUsage (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetBrowserPlatformUsage");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetBrowserPlatformUsage");
            
    
            var path = "/stats/outbound/clicks/platforms";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBrowserPlatformUsage: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBrowserPlatformUsage: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20034) ApiClient.Deserialize(response.Content, typeof(InlineResponse20034), response.Headers);
        }
    
        /// <summary>
        /// Get browser usage (Gets an overview of the browsers used to open links in your emails. This is only recorded when Link Tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20033</returns>            
        public InlineResponse20033 GetBrowserUsage (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetBrowserUsage");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetBrowserUsage");
            
    
            var path = "/stats/outbound/clicks/browserfamilies";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBrowserUsage: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetBrowserUsage: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20033) ApiClient.Deserialize(response.Content, typeof(InlineResponse20033), response.Headers);
        }
    
        /// <summary>
        /// Get click counts (Gets total counts of unique links that were clicked.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20032</returns>            
        public InlineResponse20032 GetClickCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetClickCounts");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetClickCounts");
            
    
            var path = "/stats/outbound/clicks";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetClickCounts: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetClickCounts: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20032) ApiClient.Deserialize(response.Content, typeof(InlineResponse20032), response.Headers);
        }
    
        /// <summary>
        /// Get click location (Gets an overview of which part of the email links were clicked from (HTML or Text). This is only recorded when Link Tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20035</returns>            
        public InlineResponse20035 GetClickLocation (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetClickLocation");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetClickLocation");
            
    
            var path = "/stats/outbound/clicks/location";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetClickLocation: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetClickLocation: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20035) ApiClient.Deserialize(response.Content, typeof(InlineResponse20035), response.Headers);
        }
    
        /// <summary>
        /// Get email client usage (Gets an overview of the email clients used to open your emails. This is only recorded when open tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20030</returns>            
        public InlineResponse20030 GetEmailClientUsage (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetEmailClientUsage");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetEmailClientUsage");
            
    
            var path = "/stats/outbound/opens/emailclients";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEmailClientUsage: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEmailClientUsage: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20030) ApiClient.Deserialize(response.Content, typeof(InlineResponse20030), response.Headers);
        }
    
        /// <summary>
        /// Get email open counts (Gets total counts of recipients who opened your emails. This is only recorded when open tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20028</returns>            
        public InlineResponse20028 GetEmailOpenCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetEmailOpenCounts");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetEmailOpenCounts");
            
    
            var path = "/stats/outbound/opens";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEmailOpenCounts: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEmailOpenCounts: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20028) ApiClient.Deserialize(response.Content, typeof(InlineResponse20028), response.Headers);
        }
    
        /// <summary>
        /// Get email platform usage (Gets an overview of the platforms used to open your emails. This is only recorded when open tracking is enabled for that email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20029</returns>            
        public InlineResponse20029 GetEmailPlatformUsage (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetEmailPlatformUsage");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetEmailPlatformUsage");
            
    
            var path = "/stats/outbound/opens/platforms";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEmailPlatformUsage: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEmailPlatformUsage: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20029) ApiClient.Deserialize(response.Content, typeof(InlineResponse20029), response.Headers);
        }
    
        /// <summary>
        /// Get email read times (Gets the length of time that recipients read emails along with counts for each time. This is only recorded when open tracking is enabled for that email. Read time tracking stops at 20 seconds, so any read times above that will appear in the 20s+ field.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20031</returns>            
        public InlineResponse20031 GetEmailReadTimes (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetEmailReadTimes");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetEmailReadTimes");
            
    
            var path = "/stats/outbound/opens/readtimes";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEmailReadTimes: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEmailReadTimes: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20031) ApiClient.Deserialize(response.Content, typeof(InlineResponse20031), response.Headers);
        }
    
        /// <summary>
        /// Get outbound overview (Gets a brief overview of statistics for all of your outbound email.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20023</returns>            
        public InlineResponse20023 GetOutboundOverview (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetOutboundOverview");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetOutboundOverview");
            
    
            var path = "/stats/outbound";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOutboundOverview: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOutboundOverview: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20023) ApiClient.Deserialize(response.Content, typeof(InlineResponse20023), response.Headers);
        }
    
        /// <summary>
        /// Get sent counts (Gets a total count of emails you’ve sent out.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20024</returns>            
        public InlineResponse20024 GetSentCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetSentCounts");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetSentCounts");
            
    
            var path = "/stats/outbound/sends";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetSentCounts: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetSentCounts: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20024) ApiClient.Deserialize(response.Content, typeof(InlineResponse20024), response.Headers);
        }
    
        /// <summary>
        /// Get spam complaints (Gets a total count of recipients who have marked your email as spam.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20026</returns>            
        public InlineResponse20026 GetSpamComplaints (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetSpamComplaints");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetSpamComplaints");
            
    
            var path = "/stats/outbound/spam";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetSpamComplaints: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetSpamComplaints: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20026) ApiClient.Deserialize(response.Content, typeof(InlineResponse20026), response.Headers);
        }
    
        /// <summary>
        /// Get tracked email counts (Gets a total count of emails you’ve sent with open tracking or link tracking enabled.) Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="fromdate">- Filter stats starting from the date specified (inclusive). e.g. 2014-01-01. </param> 
        /// <param name="todate">- Filter stats up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20027</returns>            
        public InlineResponse20027 GetTrackedEmailCounts (string accept, string xTrxApiKey, string tag, string fromdate, string todate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetTrackedEmailCounts");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetTrackedEmailCounts");
            
    
            var path = "/stats/outbound/tracked";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTrackedEmailCounts: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTrackedEmailCounts: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20027) ApiClient.Deserialize(response.Content, typeof(InlineResponse20027), response.Headers);
        }
    
    }
}
