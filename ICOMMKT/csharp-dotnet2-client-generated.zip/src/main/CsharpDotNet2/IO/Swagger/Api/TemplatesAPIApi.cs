using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ITemplatesAPIApi
    {
        /// <summary>
        /// Create a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="body">Create a template</param>
        /// <returns>InlineResponse2008</returns>
        InlineResponse2008 CreateTemplate (string accept, string xTrxApiKey, CreateTemplate body);
        /// <summary>
        /// Delete a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="templateIdOrAlias"></param>
        /// <returns>InlineResponse20010</returns>
        InlineResponse20010 DeleteTemplate (string accept, string xTrxApiKey, int? templateIdOrAlias);
        /// <summary>
        /// Edit a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="templateIdOrAlias"></param>
        /// <param name="body">Edit a template</param>
        /// <returns>InlineResponse2008</returns>
        InlineResponse2008 EditTemplate (string accept, string xTrxApiKey, int? templateIdOrAlias, EditTemplate body);
        /// <summary>
        /// List templates Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="count">- The number of templates to return. </param>
        /// <param name="offset">- The number of templates to \&quot;skip\&quot; before returning results. </param>
        /// <returns>InlineResponse2007</returns>
        InlineResponse2007 GetListTemplates (string accept, string xTrxApiKey, int? count, int? offset);
        /// <summary>
        /// Get a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="templateIdOrAlias"></param>
        /// <returns>InlineResponse2009</returns>
        InlineResponse2009 GetTemplate (string accept, string xTrxApiKey, int? templateIdOrAlias);
        /// <summary>
        /// Send batch with templates Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="body">Send batch with templates</param>
        /// <returns>Object</returns>
        Object SendBatchTemplatedEmail (string contentType, string accept, string xTrxApiKey, SendBatchTemplatedEmail body);
        /// <summary>
        /// Send email with template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="body">Send email with template</param>
        /// <returns>InlineResponse20012</returns>
        InlineResponse20012 SendTemplatedEmail (string accept, string xTrxApiKey, SendTemplatedEmail body);
        /// <summary>
        /// Validate a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="body">Validate a template</param>
        /// <returns>InlineResponse20011</returns>
        InlineResponse20011 ValidateTemplate (string accept, string xTrxApiKey, ValidateTemplate body);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class TemplatesAPIApi : ITemplatesAPIApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TemplatesAPIApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public TemplatesAPIApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="TemplatesAPIApi"/> class.
        /// </summary>
        /// <returns></returns>
        public TemplatesAPIApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Create a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="body">Create a template</param> 
        /// <returns>InlineResponse2008</returns>            
        public InlineResponse2008 CreateTemplate (string accept, string xTrxApiKey, CreateTemplate body)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling CreateTemplate");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling CreateTemplate");
            
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling CreateTemplate");
            
    
            var path = "/templates";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                        postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CreateTemplate: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CreateTemplate: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2008) ApiClient.Deserialize(response.Content, typeof(InlineResponse2008), response.Headers);
        }
    
        /// <summary>
        /// Delete a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="templateIdOrAlias"></param> 
        /// <returns>InlineResponse20010</returns>            
        public InlineResponse20010 DeleteTemplate (string accept, string xTrxApiKey, int? templateIdOrAlias)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling DeleteTemplate");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling DeleteTemplate");
            
            // verify the required parameter 'templateIdOrAlias' is set
            if (templateIdOrAlias == null) throw new ApiException(400, "Missing required parameter 'templateIdOrAlias' when calling DeleteTemplate");
            
    
            var path = "/templates/{templateIdOrAlias}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "templateIdOrAlias" + "}", ApiClient.ParameterToString(templateIdOrAlias));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteTemplate: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteTemplate: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20010) ApiClient.Deserialize(response.Content, typeof(InlineResponse20010), response.Headers);
        }
    
        /// <summary>
        /// Edit a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="templateIdOrAlias"></param> 
        /// <param name="body">Edit a template</param> 
        /// <returns>InlineResponse2008</returns>            
        public InlineResponse2008 EditTemplate (string accept, string xTrxApiKey, int? templateIdOrAlias, EditTemplate body)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling EditTemplate");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling EditTemplate");
            
            // verify the required parameter 'templateIdOrAlias' is set
            if (templateIdOrAlias == null) throw new ApiException(400, "Missing required parameter 'templateIdOrAlias' when calling EditTemplate");
            
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling EditTemplate");
            
    
            var path = "/templates/{templateIdOrAlias}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "templateIdOrAlias" + "}", ApiClient.ParameterToString(templateIdOrAlias));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                        postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling EditTemplate: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling EditTemplate: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2008) ApiClient.Deserialize(response.Content, typeof(InlineResponse2008), response.Headers);
        }
    
        /// <summary>
        /// List templates Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="count">- The number of templates to return. </param> 
        /// <param name="offset">- The number of templates to \&quot;skip\&quot; before returning results. </param> 
        /// <returns>InlineResponse2007</returns>            
        public InlineResponse2007 GetListTemplates (string accept, string xTrxApiKey, int? count, int? offset)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetListTemplates");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetListTemplates");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetListTemplates");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetListTemplates");
            
    
            var path = "/templates";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("Count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("Offset", ApiClient.ParameterToString(offset)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetListTemplates: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetListTemplates: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2007) ApiClient.Deserialize(response.Content, typeof(InlineResponse2007), response.Headers);
        }
    
        /// <summary>
        /// Get a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="templateIdOrAlias"></param> 
        /// <returns>InlineResponse2009</returns>            
        public InlineResponse2009 GetTemplate (string accept, string xTrxApiKey, int? templateIdOrAlias)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetTemplate");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetTemplate");
            
            // verify the required parameter 'templateIdOrAlias' is set
            if (templateIdOrAlias == null) throw new ApiException(400, "Missing required parameter 'templateIdOrAlias' when calling GetTemplate");
            
    
            var path = "/templates/{templateIdOrAlias}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "templateIdOrAlias" + "}", ApiClient.ParameterToString(templateIdOrAlias));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTemplate: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetTemplate: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse2009) ApiClient.Deserialize(response.Content, typeof(InlineResponse2009), response.Headers);
        }
    
        /// <summary>
        /// Send batch with templates Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param> 
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="body">Send batch with templates</param> 
        /// <returns>Object</returns>            
        public Object SendBatchTemplatedEmail (string contentType, string accept, string xTrxApiKey, SendBatchTemplatedEmail body)
        {
            
            // verify the required parameter 'contentType' is set
            if (contentType == null) throw new ApiException(400, "Missing required parameter 'contentType' when calling SendBatchTemplatedEmail");
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling SendBatchTemplatedEmail");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling SendBatchTemplatedEmail");
            
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling SendBatchTemplatedEmail");
            
    
            var path = "/email/batchWithTemplates";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (contentType != null) headerParams.Add("Content-Type", ApiClient.ParameterToString(contentType)); // header parameter
 if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                        postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SendBatchTemplatedEmail: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SendBatchTemplatedEmail: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Object) ApiClient.Deserialize(response.Content, typeof(Object), response.Headers);
        }
    
        /// <summary>
        /// Send email with template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="body">Send email with template</param> 
        /// <returns>InlineResponse20012</returns>            
        public InlineResponse20012 SendTemplatedEmail (string accept, string xTrxApiKey, SendTemplatedEmail body)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling SendTemplatedEmail");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling SendTemplatedEmail");
            
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling SendTemplatedEmail");
            
    
            var path = "/email/withTemplate";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                        postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SendTemplatedEmail: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SendTemplatedEmail: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20012) ApiClient.Deserialize(response.Content, typeof(InlineResponse20012), response.Headers);
        }
    
        /// <summary>
        /// Validate a template Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="body">Validate a template</param> 
        /// <returns>InlineResponse20011</returns>            
        public InlineResponse20011 ValidateTemplate (string accept, string xTrxApiKey, ValidateTemplate body)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling ValidateTemplate");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling ValidateTemplate");
            
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling ValidateTemplate");
            
    
            var path = "/templates/validate";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                        postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ValidateTemplate: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ValidateTemplate: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20011) ApiClient.Deserialize(response.Content, typeof(InlineResponse20011), response.Headers);
        }
    
    }
}
