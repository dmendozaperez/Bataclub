using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IInboundRulesTriggersAPIApi
    {
        /// <summary>
        /// Create an inbound rule trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="body">Create an inbound rule trigger</param>
        /// <returns>InlineResponse20042</returns>
        InlineResponse20042 CreateInboundRuleTrigger (string contentType, string accept, string xTrxApiKey, CreateInboundRuleTrigger body);
        /// <summary>
        /// Delete a single trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="triggerid"></param>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <returns>InlineResponse20043</returns>
        InlineResponse20043 DeleteSingleTrigger (int? triggerid, string accept, string xTrxApiKey);
        /// <summary>
        /// List inbound rule triggers Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="count">- Number of servers to return per request. </param>
        /// <param name="offset">- Number of servers to skip. </param>
        /// <returns>InlineResponse20041</returns>
        InlineResponse20041 GetInboundRuleTriggers (string accept, string xTrxApiKey, int? count, int? offset);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class InboundRulesTriggersAPIApi : IInboundRulesTriggersAPIApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InboundRulesTriggersAPIApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public InboundRulesTriggersAPIApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="InboundRulesTriggersAPIApi"/> class.
        /// </summary>
        /// <returns></returns>
        public InboundRulesTriggersAPIApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Create an inbound rule trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param> 
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="body">Create an inbound rule trigger</param> 
        /// <returns>InlineResponse20042</returns>            
        public InlineResponse20042 CreateInboundRuleTrigger (string contentType, string accept, string xTrxApiKey, CreateInboundRuleTrigger body)
        {
            
            // verify the required parameter 'contentType' is set
            if (contentType == null) throw new ApiException(400, "Missing required parameter 'contentType' when calling CreateInboundRuleTrigger");
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling CreateInboundRuleTrigger");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling CreateInboundRuleTrigger");
            
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling CreateInboundRuleTrigger");
            
    
            var path = "/triggers/inboundrules";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (contentType != null) headerParams.Add("Content-Type", ApiClient.ParameterToString(contentType)); // header parameter
 if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                        postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CreateInboundRuleTrigger: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CreateInboundRuleTrigger: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20042) ApiClient.Deserialize(response.Content, typeof(InlineResponse20042), response.Headers);
        }
    
        /// <summary>
        /// Delete a single trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="triggerid"></param> 
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <returns>InlineResponse20043</returns>            
        public InlineResponse20043 DeleteSingleTrigger (int? triggerid, string accept, string xTrxApiKey)
        {
            
            // verify the required parameter 'triggerid' is set
            if (triggerid == null) throw new ApiException(400, "Missing required parameter 'triggerid' when calling DeleteSingleTrigger");
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling DeleteSingleTrigger");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling DeleteSingleTrigger");
            
    
            var path = "/triggers/inboundrules/{triggerid}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "triggerid" + "}", ApiClient.ParameterToString(triggerid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteSingleTrigger: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteSingleTrigger: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20043) ApiClient.Deserialize(response.Content, typeof(InlineResponse20043), response.Headers);
        }
    
        /// <summary>
        /// List inbound rule triggers Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="count">- Number of servers to return per request. </param> 
        /// <param name="offset">- Number of servers to skip. </param> 
        /// <returns>InlineResponse20041</returns>            
        public InlineResponse20041 GetInboundRuleTriggers (string accept, string xTrxApiKey, int? count, int? offset)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetInboundRuleTriggers");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetInboundRuleTriggers");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetInboundRuleTriggers");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetInboundRuleTriggers");
            
    
            var path = "/triggers/inboundrules";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("offset", ApiClient.ParameterToString(offset)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetInboundRuleTriggers: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetInboundRuleTriggers: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20041) ApiClient.Deserialize(response.Content, typeof(InlineResponse20041), response.Headers);
        }
    
    }
}
