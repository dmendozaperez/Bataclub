using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ITagsTriggersAPIApi
    {
        /// <summary>
        /// Create a trigger for a tag Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="body">Create a trigger for a tag</param>
        /// <returns>InlineResponse20037</returns>
        InlineResponse20037 CreateTriggerForTag (string contentType, string accept, string xTrxApiKey, CreateTriggerForTag body);
        /// <summary>
        /// Delete a single trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="triggerid"></param>
        /// <returns>InlineResponse20040</returns>
        InlineResponse20040 DeleteSingleATrigger (string accept, string xTrxApiKey, int? triggerid);
        /// <summary>
        /// Edit a single trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="triggerid"></param>
        /// <param name="body">Edit a single trigger</param>
        /// <returns>InlineResponse20039</returns>
        InlineResponse20039 EditSingleTrigger (string contentType, string accept, string xTrxApiKey, int? triggerid, EditSingleTrigger body);
        /// <summary>
        /// Get a single trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="triggerid"></param>
        /// <returns>InlineResponse20038</returns>
        InlineResponse20038 GetSingleTrigger (string accept, string xTrxApiKey, int? triggerid);
        /// <summary>
        /// Search triggers Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="count">- Number of records to return per request. </param>
        /// <param name="offset">- Number of records to skip. </param>
        /// <param name="matchName">- Filter by delivery tag. </param>
        /// <returns>InlineResponse20036</returns>
        InlineResponse20036 SearchTriggers (string contentType, string accept, string xTrxApiKey, int? count, int? offset, int? matchName);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class TagsTriggersAPIApi : ITagsTriggersAPIApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TagsTriggersAPIApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public TagsTriggersAPIApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="TagsTriggersAPIApi"/> class.
        /// </summary>
        /// <returns></returns>
        public TagsTriggersAPIApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Create a trigger for a tag Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param> 
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="body">Create a trigger for a tag</param> 
        /// <returns>InlineResponse20037</returns>            
        public InlineResponse20037 CreateTriggerForTag (string contentType, string accept, string xTrxApiKey, CreateTriggerForTag body)
        {
            
            // verify the required parameter 'contentType' is set
            if (contentType == null) throw new ApiException(400, "Missing required parameter 'contentType' when calling CreateTriggerForTag");
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling CreateTriggerForTag");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling CreateTriggerForTag");
            
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling CreateTriggerForTag");
            
    
            var path = "/triggers/tags";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (contentType != null) headerParams.Add("Content-Type", ApiClient.ParameterToString(contentType)); // header parameter
 if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                        postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CreateTriggerForTag: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CreateTriggerForTag: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20037) ApiClient.Deserialize(response.Content, typeof(InlineResponse20037), response.Headers);
        }
    
        /// <summary>
        /// Delete a single trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="triggerid"></param> 
        /// <returns>InlineResponse20040</returns>            
        public InlineResponse20040 DeleteSingleATrigger (string accept, string xTrxApiKey, int? triggerid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling DeleteSingleATrigger");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling DeleteSingleATrigger");
            
            // verify the required parameter 'triggerid' is set
            if (triggerid == null) throw new ApiException(400, "Missing required parameter 'triggerid' when calling DeleteSingleATrigger");
            
    
            var path = "/triggers/tags/{triggerid}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "triggerid" + "}", ApiClient.ParameterToString(triggerid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteSingleATrigger: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteSingleATrigger: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20040) ApiClient.Deserialize(response.Content, typeof(InlineResponse20040), response.Headers);
        }
    
        /// <summary>
        /// Edit a single trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param> 
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="triggerid"></param> 
        /// <param name="body">Edit a single trigger</param> 
        /// <returns>InlineResponse20039</returns>            
        public InlineResponse20039 EditSingleTrigger (string contentType, string accept, string xTrxApiKey, int? triggerid, EditSingleTrigger body)
        {
            
            // verify the required parameter 'contentType' is set
            if (contentType == null) throw new ApiException(400, "Missing required parameter 'contentType' when calling EditSingleTrigger");
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling EditSingleTrigger");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling EditSingleTrigger");
            
            // verify the required parameter 'triggerid' is set
            if (triggerid == null) throw new ApiException(400, "Missing required parameter 'triggerid' when calling EditSingleTrigger");
            
            // verify the required parameter 'body' is set
            if (body == null) throw new ApiException(400, "Missing required parameter 'body' when calling EditSingleTrigger");
            
    
            var path = "/triggers/tags/{triggerid}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "triggerid" + "}", ApiClient.ParameterToString(triggerid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (contentType != null) headerParams.Add("Content-Type", ApiClient.ParameterToString(contentType)); // header parameter
 if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                        postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling EditSingleTrigger: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling EditSingleTrigger: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20039) ApiClient.Deserialize(response.Content, typeof(InlineResponse20039), response.Headers);
        }
    
        /// <summary>
        /// Get a single trigger Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="triggerid"></param> 
        /// <returns>InlineResponse20038</returns>            
        public InlineResponse20038 GetSingleTrigger (string accept, string xTrxApiKey, int? triggerid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetSingleTrigger");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetSingleTrigger");
            
            // verify the required parameter 'triggerid' is set
            if (triggerid == null) throw new ApiException(400, "Missing required parameter 'triggerid' when calling GetSingleTrigger");
            
    
            var path = "/triggers/tags/{triggerid}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "triggerid" + "}", ApiClient.ParameterToString(triggerid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetSingleTrigger: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetSingleTrigger: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20038) ApiClient.Deserialize(response.Content, typeof(InlineResponse20038), response.Headers);
        }
    
        /// <summary>
        /// Search triggers Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="contentType">- application/json </param> 
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="count">- Number of records to return per request. </param> 
        /// <param name="offset">- Number of records to skip. </param> 
        /// <param name="matchName">- Filter by delivery tag. </param> 
        /// <returns>InlineResponse20036</returns>            
        public InlineResponse20036 SearchTriggers (string contentType, string accept, string xTrxApiKey, int? count, int? offset, int? matchName)
        {
            
            // verify the required parameter 'contentType' is set
            if (contentType == null) throw new ApiException(400, "Missing required parameter 'contentType' when calling SearchTriggers");
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling SearchTriggers");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling SearchTriggers");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling SearchTriggers");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling SearchTriggers");
            
            // verify the required parameter 'matchName' is set
            if (matchName == null) throw new ApiException(400, "Missing required parameter 'matchName' when calling SearchTriggers");
            
    
            var path = "/triggers/tags";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("offset", ApiClient.ParameterToString(offset)); // query parameter
 if (matchName != null) queryParams.Add("match_name", ApiClient.ParameterToString(matchName)); // query parameter
             if (contentType != null) headerParams.Add("Content-Type", ApiClient.ParameterToString(contentType)); // header parameter
 if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SearchTriggers: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SearchTriggers: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20036) ApiClient.Deserialize(response.Content, typeof(InlineResponse20036), response.Headers);
        }
    
    }
}
