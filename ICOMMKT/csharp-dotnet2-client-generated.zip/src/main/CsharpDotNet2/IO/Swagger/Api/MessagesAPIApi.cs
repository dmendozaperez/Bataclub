using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IMessagesAPIApi
    {
        /// <summary>
        /// Bypass rules for a blocked inbound message Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="messageid"></param>
        /// <returns>InlineResponse20018</returns>
        InlineResponse20018 BypassRulesForBlockedInboundMessage (string accept, string xTrxApiKey, int? messageid);
        /// <summary>
        /// Clicks for a single message Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="messageid"></param>
        /// <param name="count">- Number of message opens to return per request. Max 500. </param>
        /// <param name="offset">- Number of messages to skip </param>
        /// <returns>InlineResponse20022</returns>
        InlineResponse20022 GetClicksForSingleMessage (string accept, string xTrxApiKey, int? messageid, int? count, int? offset);
        /// <summary>
        /// Inbound message details Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="messageid"></param>
        /// <returns>InlineResponse20017</returns>
        InlineResponse20017 GetInboundMessageDetails (string accept, string xTrxApiKey, int? messageid);
        /// <summary>
        /// Inbound message search Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="count">- Number of records to return per request. Max 500. </param>
        /// <param name="offset">- Number of records to skip. </param>
        /// <param name="recipient">- Filter by the user who was receiving the email. </param>
        /// <param name="fromemail">- Filter by the sender email address. </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="subject">- Filter by email subject. </param>
        /// <param name="mailboxhash">- Filter by mailboxhash. </param>
        /// <param name="status">- Filter by status (blocked, processed / sent, queued, failed, scheduled) </param>
        /// <param name="todate">- Filter messages up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <param name="fromdate">- Filter messages starting from the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20016</returns>
        InlineResponse20016 GetInboundMessageSearch (string accept, string xTrxApiKey, int? count, int? offset, string recipient, string fromemail, string tag, string subject, string mailboxhash, string status, string todate, string fromdate);
        /// <summary>
        /// Message clicks Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="count">- Number of message opens to return per request. Max 500. </param>
        /// <param name="offset">- Number of messages to skip </param>
        /// <param name="recipient">- Filter by To, Cc, Bcc </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="clientName">- Filter by client name, i.e. Outlook, Gmail </param>
        /// <param name="clientCompany">- Filter by company, i.e. Microsoft, Apple, Google </param>
        /// <param name="clientFamily">- Filter by client family, i.e. OS X, Chrome </param>
        /// <param name="osName">- Filter by full OS name and specific version, i.e. OS X 10.9 Mavericks, Windows 7 </param>
        /// <param name="osFamily">- Filter by kind of OS used without specific version, i.e. OS X, Windows </param>
        /// <param name="osCompany">- Filter by company which produced the OS, i.e. Apple Computer, Inc., Microsoft Corporation </param>
        /// <param name="platform">- Filter by platform, i.e. webmail, desktop, mobile </param>
        /// <param name="country">- Filter by country messages were opened in, i.e. Denmark, Russia </param>
        /// <param name="region">- Filter by full name of region messages were opened in, i.e. Moscow, New York </param>
        /// <param name="city">- Filter by full name of city messages were opened in, i.e. Minneapolis, Philadelphia </param>
        /// <returns>InlineResponse20022</returns>
        InlineResponse20022 GetMessageClicks (string accept, string xTrxApiKey, int? count, int? offset, string recipient, string tag, string clientName, string clientCompany, string clientFamily, string osName, string osFamily, string osCompany, string platform, string country, string region, string city);
        /// <summary>
        /// Message opens Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="count">- Number of message opens to return per request. Max 500. </param>
        /// <param name="offset">- Number of messages to skip </param>
        /// <param name="recipient">- Filter by To, Cc, Bcc </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="clientName">- Filter by client name, i.e. Outlook, Gmail </param>
        /// <param name="clientCompany">- Filter by company, i.e. Microsoft, Apple, Google </param>
        /// <param name="clientFamily">- Filter by client family, i.e. OS X, Chrome </param>
        /// <param name="osName">- Filter by full OS name and specific version, i.e. OS X 10.9 Mavericks, Windows 7 </param>
        /// <param name="osFamily">- Filter by kind of OS used without specific version, i.e. OS X, Windows </param>
        /// <param name="osCompany">- Filter by company which produced the OS, i.e. Apple Computer, Inc., Microsoft Corporation </param>
        /// <param name="platform">- Filter by platform, i.e. webmail, desktop, mobile </param>
        /// <param name="country">- Filter by country messages were opened in, i.e. Denmark, Russia </param>
        /// <param name="region">- Filter by full name of region messages were opened in, i.e. Moscow, New York </param>
        /// <param name="city">- Filter by full name of city messages were opened in, i.e. Minneapolis, Philadelphia </param>
        /// <returns>InlineResponse20020</returns>
        InlineResponse20020 GetMessageOpens (string accept, string xTrxApiKey, int? count, int? offset, string recipient, string tag, string clientName, string clientCompany, string clientFamily, string osName, string osFamily, string osCompany, string platform, string country, string region, string city);
        /// <summary>
        /// Opens for a single message Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="messageid"></param>
        /// <param name="count">- Number of message opens to return per request. Max 500. </param>
        /// <param name="offset">- Number of messages to skip </param>
        /// <returns>InlineResponse20021</returns>
        InlineResponse20021 GetOpensForSingleMessage (string accept, string xTrxApiKey, int? messageid, int? count, int? offset);
        /// <summary>
        /// Outbound message details Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="messageid"></param>
        /// <returns>InlineResponse20014</returns>
        InlineResponse20014 GetOutboundMessageDetails (string accept, string xTrxApiKey, int? messageid);
        /// <summary>
        /// Outbound message dump Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="messageid"></param>
        /// <returns>InlineResponse20015</returns>
        InlineResponse20015 GetOutboundMessageDump (string accept, string xTrxApiKey, int? messageid);
        /// <summary>
        /// Outbound message search Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="count">- Number of records to return per request. Max 500. </param>
        /// <param name="offset">- Number of records to skip. </param>
        /// <param name="subject">- Filter by email subject. </param>
        /// <param name="recipient">- Filter by the user who was receiving the email. </param>
        /// <param name="fromemail">- Filter by the sender email address. </param>
        /// <param name="tag">- Filter by tag </param>
        /// <param name="status">- Filter by status (queued or sent / processed). Note that sent and processed will return the same results and can be used interchangeably. </param>
        /// <param name="todate">- Filter messages up to the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <param name="fromdate">- Filter messages starting from the date specified (inclusive). e.g. 2014-02-01. </param>
        /// <returns>InlineResponse20013</returns>
        InlineResponse20013 GetOutboundMessageSearch (string accept, string xTrxApiKey, int? count, int? offset, string subject, string recipient, string fromemail, string tag, string status, string todate, string fromdate);
        /// <summary>
        /// Retry a failed inbound message for processing Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param>
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param>
        /// <param name="messageid"></param>
        /// <returns>InlineResponse20019</returns>
        InlineResponse20019 RetryFailedInboundMessageForProcessing (string accept, string xTrxApiKey, int? messageid);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class MessagesAPIApi : IMessagesAPIApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MessagesAPIApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public MessagesAPIApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="MessagesAPIApi"/> class.
        /// </summary>
        /// <returns></returns>
        public MessagesAPIApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Bypass rules for a blocked inbound message Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="messageid"></param> 
        /// <returns>InlineResponse20018</returns>            
        public InlineResponse20018 BypassRulesForBlockedInboundMessage (string accept, string xTrxApiKey, int? messageid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling BypassRulesForBlockedInboundMessage");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling BypassRulesForBlockedInboundMessage");
            
            // verify the required parameter 'messageid' is set
            if (messageid == null) throw new ApiException(400, "Missing required parameter 'messageid' when calling BypassRulesForBlockedInboundMessage");
            
    
            var path = "/messages/inbound/{messageid}/bypass";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "messageid" + "}", ApiClient.ParameterToString(messageid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling BypassRulesForBlockedInboundMessage: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling BypassRulesForBlockedInboundMessage: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20018) ApiClient.Deserialize(response.Content, typeof(InlineResponse20018), response.Headers);
        }
    
        /// <summary>
        /// Clicks for a single message Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="messageid"></param> 
        /// <param name="count">- Number of message opens to return per request. Max 500. </param> 
        /// <param name="offset">- Number of messages to skip </param> 
        /// <returns>InlineResponse20022</returns>            
        public InlineResponse20022 GetClicksForSingleMessage (string accept, string xTrxApiKey, int? messageid, int? count, int? offset)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetClicksForSingleMessage");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetClicksForSingleMessage");
            
            // verify the required parameter 'messageid' is set
            if (messageid == null) throw new ApiException(400, "Missing required parameter 'messageid' when calling GetClicksForSingleMessage");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetClicksForSingleMessage");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetClicksForSingleMessage");
            
    
            var path = "/messages/outbound/clicks/{messageid}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "messageid" + "}", ApiClient.ParameterToString(messageid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("offset", ApiClient.ParameterToString(offset)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetClicksForSingleMessage: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetClicksForSingleMessage: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20022) ApiClient.Deserialize(response.Content, typeof(InlineResponse20022), response.Headers);
        }
    
        /// <summary>
        /// Inbound message details Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="messageid"></param> 
        /// <returns>InlineResponse20017</returns>            
        public InlineResponse20017 GetInboundMessageDetails (string accept, string xTrxApiKey, int? messageid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetInboundMessageDetails");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetInboundMessageDetails");
            
            // verify the required parameter 'messageid' is set
            if (messageid == null) throw new ApiException(400, "Missing required parameter 'messageid' when calling GetInboundMessageDetails");
            
    
            var path = "/messages/inbound/{messageid}/details";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "messageid" + "}", ApiClient.ParameterToString(messageid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetInboundMessageDetails: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetInboundMessageDetails: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20017) ApiClient.Deserialize(response.Content, typeof(InlineResponse20017), response.Headers);
        }
    
        /// <summary>
        /// Inbound message search Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="count">- Number of records to return per request. Max 500. </param> 
        /// <param name="offset">- Number of records to skip. </param> 
        /// <param name="recipient">- Filter by the user who was receiving the email. </param> 
        /// <param name="fromemail">- Filter by the sender email address. </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="subject">- Filter by email subject. </param> 
        /// <param name="mailboxhash">- Filter by mailboxhash. </param> 
        /// <param name="status">- Filter by status (blocked, processed / sent, queued, failed, scheduled) </param> 
        /// <param name="todate">- Filter messages up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <param name="fromdate">- Filter messages starting from the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20016</returns>            
        public InlineResponse20016 GetInboundMessageSearch (string accept, string xTrxApiKey, int? count, int? offset, string recipient, string fromemail, string tag, string subject, string mailboxhash, string status, string todate, string fromdate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetInboundMessageSearch");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetInboundMessageSearch");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetInboundMessageSearch");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetInboundMessageSearch");
            
    
            var path = "/messages/inbound";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("offset", ApiClient.ParameterToString(offset)); // query parameter
 if (recipient != null) queryParams.Add("recipient", ApiClient.ParameterToString(recipient)); // query parameter
 if (fromemail != null) queryParams.Add("fromemail", ApiClient.ParameterToString(fromemail)); // query parameter
 if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (subject != null) queryParams.Add("subject", ApiClient.ParameterToString(subject)); // query parameter
 if (mailboxhash != null) queryParams.Add("mailboxhash", ApiClient.ParameterToString(mailboxhash)); // query parameter
 if (status != null) queryParams.Add("status", ApiClient.ParameterToString(status)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetInboundMessageSearch: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetInboundMessageSearch: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20016) ApiClient.Deserialize(response.Content, typeof(InlineResponse20016), response.Headers);
        }
    
        /// <summary>
        /// Message clicks Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="count">- Number of message opens to return per request. Max 500. </param> 
        /// <param name="offset">- Number of messages to skip </param> 
        /// <param name="recipient">- Filter by To, Cc, Bcc </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="clientName">- Filter by client name, i.e. Outlook, Gmail </param> 
        /// <param name="clientCompany">- Filter by company, i.e. Microsoft, Apple, Google </param> 
        /// <param name="clientFamily">- Filter by client family, i.e. OS X, Chrome </param> 
        /// <param name="osName">- Filter by full OS name and specific version, i.e. OS X 10.9 Mavericks, Windows 7 </param> 
        /// <param name="osFamily">- Filter by kind of OS used without specific version, i.e. OS X, Windows </param> 
        /// <param name="osCompany">- Filter by company which produced the OS, i.e. Apple Computer, Inc., Microsoft Corporation </param> 
        /// <param name="platform">- Filter by platform, i.e. webmail, desktop, mobile </param> 
        /// <param name="country">- Filter by country messages were opened in, i.e. Denmark, Russia </param> 
        /// <param name="region">- Filter by full name of region messages were opened in, i.e. Moscow, New York </param> 
        /// <param name="city">- Filter by full name of city messages were opened in, i.e. Minneapolis, Philadelphia </param> 
        /// <returns>InlineResponse20022</returns>            
        public InlineResponse20022 GetMessageClicks (string accept, string xTrxApiKey, int? count, int? offset, string recipient, string tag, string clientName, string clientCompany, string clientFamily, string osName, string osFamily, string osCompany, string platform, string country, string region, string city)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetMessageClicks");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetMessageClicks");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetMessageClicks");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetMessageClicks");
            
    
            var path = "/messages/outbound/clicks";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("offset", ApiClient.ParameterToString(offset)); // query parameter
 if (recipient != null) queryParams.Add("recipient", ApiClient.ParameterToString(recipient)); // query parameter
 if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (clientName != null) queryParams.Add("client_name", ApiClient.ParameterToString(clientName)); // query parameter
 if (clientCompany != null) queryParams.Add("client_company", ApiClient.ParameterToString(clientCompany)); // query parameter
 if (clientFamily != null) queryParams.Add("client_family", ApiClient.ParameterToString(clientFamily)); // query parameter
 if (osName != null) queryParams.Add("os_name", ApiClient.ParameterToString(osName)); // query parameter
 if (osFamily != null) queryParams.Add("os_family", ApiClient.ParameterToString(osFamily)); // query parameter
 if (osCompany != null) queryParams.Add("os_company", ApiClient.ParameterToString(osCompany)); // query parameter
 if (platform != null) queryParams.Add("platform", ApiClient.ParameterToString(platform)); // query parameter
 if (country != null) queryParams.Add("country", ApiClient.ParameterToString(country)); // query parameter
 if (region != null) queryParams.Add("region", ApiClient.ParameterToString(region)); // query parameter
 if (city != null) queryParams.Add("city", ApiClient.ParameterToString(city)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetMessageClicks: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetMessageClicks: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20022) ApiClient.Deserialize(response.Content, typeof(InlineResponse20022), response.Headers);
        }
    
        /// <summary>
        /// Message opens Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="count">- Number of message opens to return per request. Max 500. </param> 
        /// <param name="offset">- Number of messages to skip </param> 
        /// <param name="recipient">- Filter by To, Cc, Bcc </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="clientName">- Filter by client name, i.e. Outlook, Gmail </param> 
        /// <param name="clientCompany">- Filter by company, i.e. Microsoft, Apple, Google </param> 
        /// <param name="clientFamily">- Filter by client family, i.e. OS X, Chrome </param> 
        /// <param name="osName">- Filter by full OS name and specific version, i.e. OS X 10.9 Mavericks, Windows 7 </param> 
        /// <param name="osFamily">- Filter by kind of OS used without specific version, i.e. OS X, Windows </param> 
        /// <param name="osCompany">- Filter by company which produced the OS, i.e. Apple Computer, Inc., Microsoft Corporation </param> 
        /// <param name="platform">- Filter by platform, i.e. webmail, desktop, mobile </param> 
        /// <param name="country">- Filter by country messages were opened in, i.e. Denmark, Russia </param> 
        /// <param name="region">- Filter by full name of region messages were opened in, i.e. Moscow, New York </param> 
        /// <param name="city">- Filter by full name of city messages were opened in, i.e. Minneapolis, Philadelphia </param> 
        /// <returns>InlineResponse20020</returns>            
        public InlineResponse20020 GetMessageOpens (string accept, string xTrxApiKey, int? count, int? offset, string recipient, string tag, string clientName, string clientCompany, string clientFamily, string osName, string osFamily, string osCompany, string platform, string country, string region, string city)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetMessageOpens");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetMessageOpens");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetMessageOpens");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetMessageOpens");
            
    
            var path = "/messages/outbound/opens";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("offset", ApiClient.ParameterToString(offset)); // query parameter
 if (recipient != null) queryParams.Add("recipient", ApiClient.ParameterToString(recipient)); // query parameter
 if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (clientName != null) queryParams.Add("client_name", ApiClient.ParameterToString(clientName)); // query parameter
 if (clientCompany != null) queryParams.Add("client_company", ApiClient.ParameterToString(clientCompany)); // query parameter
 if (clientFamily != null) queryParams.Add("client_family", ApiClient.ParameterToString(clientFamily)); // query parameter
 if (osName != null) queryParams.Add("os_name", ApiClient.ParameterToString(osName)); // query parameter
 if (osFamily != null) queryParams.Add("os_family", ApiClient.ParameterToString(osFamily)); // query parameter
 if (osCompany != null) queryParams.Add("os_company", ApiClient.ParameterToString(osCompany)); // query parameter
 if (platform != null) queryParams.Add("platform", ApiClient.ParameterToString(platform)); // query parameter
 if (country != null) queryParams.Add("country", ApiClient.ParameterToString(country)); // query parameter
 if (region != null) queryParams.Add("region", ApiClient.ParameterToString(region)); // query parameter
 if (city != null) queryParams.Add("city", ApiClient.ParameterToString(city)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetMessageOpens: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetMessageOpens: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20020) ApiClient.Deserialize(response.Content, typeof(InlineResponse20020), response.Headers);
        }
    
        /// <summary>
        /// Opens for a single message Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="messageid"></param> 
        /// <param name="count">- Number of message opens to return per request. Max 500. </param> 
        /// <param name="offset">- Number of messages to skip </param> 
        /// <returns>InlineResponse20021</returns>            
        public InlineResponse20021 GetOpensForSingleMessage (string accept, string xTrxApiKey, int? messageid, int? count, int? offset)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetOpensForSingleMessage");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetOpensForSingleMessage");
            
            // verify the required parameter 'messageid' is set
            if (messageid == null) throw new ApiException(400, "Missing required parameter 'messageid' when calling GetOpensForSingleMessage");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetOpensForSingleMessage");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetOpensForSingleMessage");
            
    
            var path = "/messages/outbound/opens/{messageid}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "messageid" + "}", ApiClient.ParameterToString(messageid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("offset", ApiClient.ParameterToString(offset)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOpensForSingleMessage: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOpensForSingleMessage: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20021) ApiClient.Deserialize(response.Content, typeof(InlineResponse20021), response.Headers);
        }
    
        /// <summary>
        /// Outbound message details Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="messageid"></param> 
        /// <returns>InlineResponse20014</returns>            
        public InlineResponse20014 GetOutboundMessageDetails (string accept, string xTrxApiKey, int? messageid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetOutboundMessageDetails");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetOutboundMessageDetails");
            
            // verify the required parameter 'messageid' is set
            if (messageid == null) throw new ApiException(400, "Missing required parameter 'messageid' when calling GetOutboundMessageDetails");
            
    
            var path = "/messages/outbound/{messageid}/details";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "messageid" + "}", ApiClient.ParameterToString(messageid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOutboundMessageDetails: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOutboundMessageDetails: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20014) ApiClient.Deserialize(response.Content, typeof(InlineResponse20014), response.Headers);
        }
    
        /// <summary>
        /// Outbound message dump Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="messageid"></param> 
        /// <returns>InlineResponse20015</returns>            
        public InlineResponse20015 GetOutboundMessageDump (string accept, string xTrxApiKey, int? messageid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetOutboundMessageDump");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetOutboundMessageDump");
            
            // verify the required parameter 'messageid' is set
            if (messageid == null) throw new ApiException(400, "Missing required parameter 'messageid' when calling GetOutboundMessageDump");
            
    
            var path = "/messages/outbound/{messageid}/dump";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "messageid" + "}", ApiClient.ParameterToString(messageid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOutboundMessageDump: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOutboundMessageDump: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20015) ApiClient.Deserialize(response.Content, typeof(InlineResponse20015), response.Headers);
        }
    
        /// <summary>
        /// Outbound message search Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="count">- Number of records to return per request. Max 500. </param> 
        /// <param name="offset">- Number of records to skip. </param> 
        /// <param name="subject">- Filter by email subject. </param> 
        /// <param name="recipient">- Filter by the user who was receiving the email. </param> 
        /// <param name="fromemail">- Filter by the sender email address. </param> 
        /// <param name="tag">- Filter by tag </param> 
        /// <param name="status">- Filter by status (queued or sent / processed). Note that sent and processed will return the same results and can be used interchangeably. </param> 
        /// <param name="todate">- Filter messages up to the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <param name="fromdate">- Filter messages starting from the date specified (inclusive). e.g. 2014-02-01. </param> 
        /// <returns>InlineResponse20013</returns>            
        public InlineResponse20013 GetOutboundMessageSearch (string accept, string xTrxApiKey, int? count, int? offset, string subject, string recipient, string fromemail, string tag, string status, string todate, string fromdate)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling GetOutboundMessageSearch");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling GetOutboundMessageSearch");
            
            // verify the required parameter 'count' is set
            if (count == null) throw new ApiException(400, "Missing required parameter 'count' when calling GetOutboundMessageSearch");
            
            // verify the required parameter 'offset' is set
            if (offset == null) throw new ApiException(400, "Missing required parameter 'offset' when calling GetOutboundMessageSearch");
            
            // verify the required parameter 'subject' is set
            if (subject == null) throw new ApiException(400, "Missing required parameter 'subject' when calling GetOutboundMessageSearch");
            
    
            var path = "/messages/outbound";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (count != null) queryParams.Add("count", ApiClient.ParameterToString(count)); // query parameter
 if (offset != null) queryParams.Add("offset", ApiClient.ParameterToString(offset)); // query parameter
 if (recipient != null) queryParams.Add("recipient", ApiClient.ParameterToString(recipient)); // query parameter
 if (fromemail != null) queryParams.Add("fromemail", ApiClient.ParameterToString(fromemail)); // query parameter
 if (tag != null) queryParams.Add("tag", ApiClient.ParameterToString(tag)); // query parameter
 if (status != null) queryParams.Add("status", ApiClient.ParameterToString(status)); // query parameter
 if (todate != null) queryParams.Add("todate", ApiClient.ParameterToString(todate)); // query parameter
 if (fromdate != null) queryParams.Add("fromdate", ApiClient.ParameterToString(fromdate)); // query parameter
 if (subject != null) queryParams.Add("subject", ApiClient.ParameterToString(subject)); // query parameter
             if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOutboundMessageSearch: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetOutboundMessageSearch: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20013) ApiClient.Deserialize(response.Content, typeof(InlineResponse20013), response.Headers);
        }
    
        /// <summary>
        /// Retry a failed inbound message for processing Authorization: Bearer X-Trx-Api-Key 
        /// </summary>
        /// <param name="accept">- application/json </param> 
        /// <param name="xTrxApiKey">- Find your API KEY in your ICOMMKT Account </param> 
        /// <param name="messageid"></param> 
        /// <returns>InlineResponse20019</returns>            
        public InlineResponse20019 RetryFailedInboundMessageForProcessing (string accept, string xTrxApiKey, int? messageid)
        {
            
            // verify the required parameter 'accept' is set
            if (accept == null) throw new ApiException(400, "Missing required parameter 'accept' when calling RetryFailedInboundMessageForProcessing");
            
            // verify the required parameter 'xTrxApiKey' is set
            if (xTrxApiKey == null) throw new ApiException(400, "Missing required parameter 'xTrxApiKey' when calling RetryFailedInboundMessageForProcessing");
            
            // verify the required parameter 'messageid' is set
            if (messageid == null) throw new ApiException(400, "Missing required parameter 'messageid' when calling RetryFailedInboundMessageForProcessing");
            
    
            var path = "/messages/inbound/{messageid}/retry";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "messageid" + "}", ApiClient.ParameterToString(messageid));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                         if (accept != null) headerParams.Add("Accept", ApiClient.ParameterToString(accept)); // header parameter
 if (xTrxApiKey != null) headerParams.Add("X-Trx-Api-Key", ApiClient.ParameterToString(xTrxApiKey)); // header parameter
                            
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling RetryFailedInboundMessageForProcessing: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling RetryFailedInboundMessageForProcessing: " + response.ErrorMessage, response.ErrorMessage);
    
            return (InlineResponse20019) ApiClient.Deserialize(response.Content, typeof(InlineResponse20019), response.Headers);
        }
    
    }
}
