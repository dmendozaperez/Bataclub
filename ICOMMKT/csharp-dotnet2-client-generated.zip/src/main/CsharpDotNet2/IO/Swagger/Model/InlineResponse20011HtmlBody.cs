using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20011HtmlBody {
    /// <summary>
    /// Gets or Sets ContentIsValid
    /// </summary>
    [DataMember(Name="ContentIsValid", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ContentIsValid")]
    public bool? ContentIsValid { get; set; }

    /// <summary>
    /// Gets or Sets ValidationErrors
    /// </summary>
    [DataMember(Name="ValidationErrors", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ValidationErrors")]
    public List<> ValidationErrors { get; set; }

    /// <summary>
    /// Gets or Sets RenderedContent
    /// </summary>
    [DataMember(Name="RenderedContent", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "RenderedContent")]
    public string RenderedContent { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20011HtmlBody {\n");
      sb.Append("  ContentIsValid: ").Append(ContentIsValid).Append("\n");
      sb.Append("  ValidationErrors: ").Append(ValidationErrors).Append("\n");
      sb.Append("  RenderedContent: ").Append(RenderedContent).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
