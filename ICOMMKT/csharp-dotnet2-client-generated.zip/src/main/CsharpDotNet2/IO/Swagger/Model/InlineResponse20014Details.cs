using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20014Details {
    /// <summary>
    /// Gets or Sets DeliveryMessage
    /// </summary>
    [DataMember(Name="DeliveryMessage", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DeliveryMessage")]
    public string DeliveryMessage { get; set; }

    /// <summary>
    /// Gets or Sets DestinationServer
    /// </summary>
    [DataMember(Name="DestinationServer", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DestinationServer")]
    public string DestinationServer { get; set; }

    /// <summary>
    /// Gets or Sets DestinationIP
    /// </summary>
    [DataMember(Name="DestinationIP", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DestinationIP")]
    public string DestinationIP { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20014Details {\n");
      sb.Append("  DeliveryMessage: ").Append(DeliveryMessage).Append("\n");
      sb.Append("  DestinationServer: ").Append(DestinationServer).Append("\n");
      sb.Append("  DestinationIP: ").Append(DestinationIP).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
