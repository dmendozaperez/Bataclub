using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20016InboundMessages {
    /// <summary>
    /// Gets or Sets From
    /// </summary>
    [DataMember(Name="From", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "From")]
    public string From { get; set; }

    /// <summary>
    /// Gets or Sets FromName
    /// </summary>
    [DataMember(Name="FromName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "FromName")]
    public string FromName { get; set; }

    /// <summary>
    /// Gets or Sets FromFull
    /// </summary>
    [DataMember(Name="FromFull", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "FromFull")]
    public List<InlineResponse20016FromFull> FromFull { get; set; }

    /// <summary>
    /// Gets or Sets To
    /// </summary>
    [DataMember(Name="To", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "To")]
    public string To { get; set; }

    /// <summary>
    /// Gets or Sets ToFull
    /// </summary>
    [DataMember(Name="ToFull", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ToFull")]
    public List<InlineResponse20016ToFull> ToFull { get; set; }

    /// <summary>
    /// Gets or Sets CcFull
    /// </summary>
    [DataMember(Name="CcFull", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "CcFull")]
    public List<> CcFull { get; set; }

    /// <summary>
    /// Gets or Sets Cc
    /// </summary>
    [DataMember(Name="Cc", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Cc")]
    public string Cc { get; set; }

    /// <summary>
    /// Gets or Sets ReplyTo
    /// </summary>
    [DataMember(Name="ReplyTo", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ReplyTo")]
    public string ReplyTo { get; set; }

    /// <summary>
    /// Gets or Sets OriginalRecipient
    /// </summary>
    [DataMember(Name="OriginalRecipient", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "OriginalRecipient")]
    public string OriginalRecipient { get; set; }

    /// <summary>
    /// Gets or Sets Subject
    /// </summary>
    [DataMember(Name="Subject", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Subject")]
    public string Subject { get; set; }

    /// <summary>
    /// Gets or Sets Date
    /// </summary>
    [DataMember(Name="Date", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Date")]
    public string Date { get; set; }

    /// <summary>
    /// Gets or Sets MailboxHash
    /// </summary>
    [DataMember(Name="MailboxHash", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "MailboxHash")]
    public string MailboxHash { get; set; }

    /// <summary>
    /// Gets or Sets Tag
    /// </summary>
    [DataMember(Name="Tag", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Tag")]
    public string Tag { get; set; }

    /// <summary>
    /// Gets or Sets Attachments
    /// </summary>
    [DataMember(Name="Attachments", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Attachments")]
    public List<InlineResponse20016Attachments> Attachments { get; set; }

    /// <summary>
    /// Gets or Sets MessageID
    /// </summary>
    [DataMember(Name="MessageID", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "MessageID")]
    public string MessageID { get; set; }

    /// <summary>
    /// Gets or Sets Status
    /// </summary>
    [DataMember(Name="Status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Status")]
    public string Status { get; set; }

    /// <summary>
    /// Gets or Sets TrackLinks
    /// </summary>
    [DataMember(Name="TrackLinks", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TrackLinks")]
    public string TrackLinks { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20016InboundMessages {\n");
      sb.Append("  From: ").Append(From).Append("\n");
      sb.Append("  FromName: ").Append(FromName).Append("\n");
      sb.Append("  FromFull: ").Append(FromFull).Append("\n");
      sb.Append("  To: ").Append(To).Append("\n");
      sb.Append("  ToFull: ").Append(ToFull).Append("\n");
      sb.Append("  CcFull: ").Append(CcFull).Append("\n");
      sb.Append("  Cc: ").Append(Cc).Append("\n");
      sb.Append("  ReplyTo: ").Append(ReplyTo).Append("\n");
      sb.Append("  OriginalRecipient: ").Append(OriginalRecipient).Append("\n");
      sb.Append("  Subject: ").Append(Subject).Append("\n");
      sb.Append("  Date: ").Append(Date).Append("\n");
      sb.Append("  MailboxHash: ").Append(MailboxHash).Append("\n");
      sb.Append("  Tag: ").Append(Tag).Append("\n");
      sb.Append("  Attachments: ").Append(Attachments).Append("\n");
      sb.Append("  MessageID: ").Append(MessageID).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  TrackLinks: ").Append(TrackLinks).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
