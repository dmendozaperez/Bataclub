using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20013Messages {
    /// <summary>
    /// Gets or Sets Tag
    /// </summary>
    [DataMember(Name="Tag", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Tag")]
    public string Tag { get; set; }

    /// <summary>
    /// Gets or Sets MessageID
    /// </summary>
    [DataMember(Name="MessageID", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "MessageID")]
    public string MessageID { get; set; }

    /// <summary>
    /// Gets or Sets To
    /// </summary>
    [DataMember(Name="To", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "To")]
    public List<InlineResponse20013To> To { get; set; }

    /// <summary>
    /// Gets or Sets Cc
    /// </summary>
    [DataMember(Name="Cc", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Cc")]
    public List<> Cc { get; set; }

    /// <summary>
    /// Gets or Sets Bcc
    /// </summary>
    [DataMember(Name="Bcc", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Bcc")]
    public List<> Bcc { get; set; }

    /// <summary>
    /// Gets or Sets Recipients
    /// </summary>
    [DataMember(Name="Recipients", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Recipients")]
    public List<Object> Recipients { get; set; }

    /// <summary>
    /// Gets or Sets ReceivedAt
    /// </summary>
    [DataMember(Name="ReceivedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ReceivedAt")]
    public string ReceivedAt { get; set; }

    /// <summary>
    /// Gets or Sets From
    /// </summary>
    [DataMember(Name="From", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "From")]
    public string From { get; set; }

    /// <summary>
    /// Gets or Sets Subject
    /// </summary>
    [DataMember(Name="Subject", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Subject")]
    public string Subject { get; set; }

    /// <summary>
    /// Gets or Sets Attachments
    /// </summary>
    [DataMember(Name="Attachments", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Attachments")]
    public List<> Attachments { get; set; }

    /// <summary>
    /// Gets or Sets Status
    /// </summary>
    [DataMember(Name="Status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Status")]
    public string Status { get; set; }

    /// <summary>
    /// Gets or Sets TrackOpens
    /// </summary>
    [DataMember(Name="TrackOpens", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TrackOpens")]
    public bool? TrackOpens { get; set; }

    /// <summary>
    /// Gets or Sets TrackLinks
    /// </summary>
    [DataMember(Name="TrackLinks", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TrackLinks")]
    public string TrackLinks { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20013Messages {\n");
      sb.Append("  Tag: ").Append(Tag).Append("\n");
      sb.Append("  MessageID: ").Append(MessageID).Append("\n");
      sb.Append("  To: ").Append(To).Append("\n");
      sb.Append("  Cc: ").Append(Cc).Append("\n");
      sb.Append("  Bcc: ").Append(Bcc).Append("\n");
      sb.Append("  Recipients: ").Append(Recipients).Append("\n");
      sb.Append("  ReceivedAt: ").Append(ReceivedAt).Append("\n");
      sb.Append("  From: ").Append(From).Append("\n");
      sb.Append("  Subject: ").Append(Subject).Append("\n");
      sb.Append("  Attachments: ").Append(Attachments).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  TrackOpens: ").Append(TrackOpens).Append("\n");
      sb.Append("  TrackLinks: ").Append(TrackLinks).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
