using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20011 {
    /// <summary>
    /// Gets or Sets AllContentIsValid
    /// </summary>
    [DataMember(Name="AllContentIsValid", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "AllContentIsValid")]
    public bool? AllContentIsValid { get; set; }

    /// <summary>
    /// Gets or Sets HtmlBody
    /// </summary>
    [DataMember(Name="HtmlBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "HtmlBody")]
    public List<InlineResponse20011HtmlBody> HtmlBody { get; set; }

    /// <summary>
    /// Gets or Sets Subject
    /// </summary>
    [DataMember(Name="Subject", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Subject")]
    public List<InlineResponse20011Subject> Subject { get; set; }

    /// <summary>
    /// Gets or Sets SuggestedTemplateModel
    /// </summary>
    [DataMember(Name="SuggestedTemplateModel", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "SuggestedTemplateModel")]
    public List<InlineResponse20011SuggestedTemplateModel> SuggestedTemplateModel { get; set; }

    /// <summary>
    /// Gets or Sets TextBody
    /// </summary>
    [DataMember(Name="TextBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TextBody")]
    public List<InlineResponse20011TextBody> TextBody { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20011 {\n");
      sb.Append("  AllContentIsValid: ").Append(AllContentIsValid).Append("\n");
      sb.Append("  HtmlBody: ").Append(HtmlBody).Append("\n");
      sb.Append("  Subject: ").Append(Subject).Append("\n");
      sb.Append("  SuggestedTemplateModel: ").Append(SuggestedTemplateModel).Append("\n");
      sb.Append("  TextBody: ").Append(TextBody).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
