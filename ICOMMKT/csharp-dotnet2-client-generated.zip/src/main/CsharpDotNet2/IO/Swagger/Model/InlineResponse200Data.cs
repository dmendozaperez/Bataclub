using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse200Data {
    /// <summary>
    /// Gets or Sets To
    /// </summary>
    [DataMember(Name="To", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "To")]
    public string To { get; set; }

    /// <summary>
    /// Gets or Sets SubmittedAt
    /// </summary>
    [DataMember(Name="SubmittedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "SubmittedAt")]
    public string SubmittedAt { get; set; }

    /// <summary>
    /// Gets or Sets MessageID
    /// </summary>
    [DataMember(Name="MessageID", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "MessageID")]
    public string MessageID { get; set; }

    /// <summary>
    /// Gets or Sets ErrorCode
    /// </summary>
    [DataMember(Name="ErrorCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ErrorCode")]
    public int? ErrorCode { get; set; }

    /// <summary>
    /// Gets or Sets Message
    /// </summary>
    [DataMember(Name="Message", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Message")]
    public string Message { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse200Data {\n");
      sb.Append("  To: ").Append(To).Append("\n");
      sb.Append("  SubmittedAt: ").Append(SubmittedAt).Append("\n");
      sb.Append("  MessageID: ").Append(MessageID).Append("\n");
      sb.Append("  ErrorCode: ").Append(ErrorCode).Append("\n");
      sb.Append("  Message: ").Append(Message).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
