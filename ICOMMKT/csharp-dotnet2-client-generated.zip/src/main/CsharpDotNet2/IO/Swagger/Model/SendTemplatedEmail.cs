using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// Send email with template
  /// </summary>
  [DataContract]
  public class SendTemplatedEmail {
    /// <summary>
    /// The template to use when sending this message. Required if TemplateAlias is not specified.
    /// </summary>
    /// <value>The template to use when sending this message. Required if TemplateAlias is not specified.</value>
    [DataMember(Name="TemplateId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TemplateId")]
    public int? TemplateId { get; set; }

    /// <summary>
    /// The alias of a template to use when sending this message. Required if TemplateID is not specified.
    /// </summary>
    /// <value>The alias of a template to use when sending this message. Required if TemplateID is not specified.</value>
    [DataMember(Name="TemplateAlias", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TemplateAlias")]
    public string TemplateAlias { get; set; }

    /// <summary>
    /// The model to be applied to the specified template to generate HtmlBody, TextBody, and Subject.
    /// </summary>
    /// <value>The model to be applied to the specified template to generate HtmlBody, TextBody, and Subject.</value>
    [DataMember(Name="TemplateModel", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TemplateModel")]
    public Object TemplateModel { get; set; }

    /// <summary>
    /// By default, if the specified template contains an HTMLBody, we will apply the style blocks as inline attributes to the rendered HTML content. You may opt-out of this behavior by passing false for this request field.
    /// </summary>
    /// <value>By default, if the specified template contains an HTMLBody, we will apply the style blocks as inline attributes to the rendered HTML content. You may opt-out of this behavior by passing false for this request field.</value>
    [DataMember(Name="InlineCss", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "InlineCss")]
    public bool? InlineCss { get; set; }

    /// <summary>
    /// The sender email address. Must have a registered and confirmed Sender Signature.
    /// </summary>
    /// <value>The sender email address. Must have a registered and confirmed Sender Signature.</value>
    [DataMember(Name="From", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "From")]
    public string From { get; set; }

    /// <summary>
    /// Recipient email address. Multiple addresses are comma separated. Max 50.
    /// </summary>
    /// <value>Recipient email address. Multiple addresses are comma separated. Max 50.</value>
    [DataMember(Name="To", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "To")]
    public string To { get; set; }

    /// <summary>
    /// Cc recipient email address. Multiple addresses are comma separated. Max 50.
    /// </summary>
    /// <value>Cc recipient email address. Multiple addresses are comma separated. Max 50.</value>
    [DataMember(Name="Cc", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Cc")]
    public string Cc { get; set; }

    /// <summary>
    /// Bcc recipient email address. Multiple addresses are comma separated. Max 50.
    /// </summary>
    /// <value>Bcc recipient email address. Multiple addresses are comma separated. Max 50.</value>
    [DataMember(Name="Bcc", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Bcc")]
    public string Bcc { get; set; }

    /// <summary>
    /// Email tag that allows you to categorize outgoing emails and get detailed statistics.
    /// </summary>
    /// <value>Email tag that allows you to categorize outgoing emails and get detailed statistics.</value>
    [DataMember(Name="Tag", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Tag")]
    public string Tag { get; set; }

    /// <summary>
    /// Reply To override email address. Defaults to the Reply To set in the sender signature.
    /// </summary>
    /// <value>Reply To override email address. Defaults to the Reply To set in the sender signature.</value>
    [DataMember(Name="ReplyTo", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ReplyTo")]
    public string ReplyTo { get; set; }

    /// <summary>
    /// List of custom headers to include.
    /// </summary>
    /// <value>List of custom headers to include.</value>
    [DataMember(Name="Headers", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Headers")]
    public string Headers { get; set; }

    /// <summary>
    /// Activate open tracking for this email.
    /// </summary>
    /// <value>Activate open tracking for this email.</value>
    [DataMember(Name="TrackOpens", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TrackOpens")]
    public bool? TrackOpens { get; set; }

    /// <summary>
    /// Activate link tracking for links in the HTML or Text bodies of this email. Possible (None, HtmlAndText, HtmlOnly, TextOnly)
    /// </summary>
    /// <value>Activate link tracking for links in the HTML or Text bodies of this email. Possible (None, HtmlAndText, HtmlOnly, TextOnly)</value>
    [DataMember(Name="TrackLinks", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TrackLinks")]
    public string TrackLinks { get; set; }

    /// <summary>
    /// List of attachments.
    /// </summary>
    /// <value>List of attachments.</value>
    [DataMember(Name="Attachments", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Attachments")]
    public List<> Attachments { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class SendTemplatedEmail {\n");
      sb.Append("  TemplateId: ").Append(TemplateId).Append("\n");
      sb.Append("  TemplateAlias: ").Append(TemplateAlias).Append("\n");
      sb.Append("  TemplateModel: ").Append(TemplateModel).Append("\n");
      sb.Append("  InlineCss: ").Append(InlineCss).Append("\n");
      sb.Append("  From: ").Append(From).Append("\n");
      sb.Append("  To: ").Append(To).Append("\n");
      sb.Append("  Cc: ").Append(Cc).Append("\n");
      sb.Append("  Bcc: ").Append(Bcc).Append("\n");
      sb.Append("  Tag: ").Append(Tag).Append("\n");
      sb.Append("  ReplyTo: ").Append(ReplyTo).Append("\n");
      sb.Append("  Headers: ").Append(Headers).Append("\n");
      sb.Append("  TrackOpens: ").Append(TrackOpens).Append("\n");
      sb.Append("  TrackLinks: ").Append(TrackLinks).Append("\n");
      sb.Append("  Attachments: ").Append(Attachments).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
