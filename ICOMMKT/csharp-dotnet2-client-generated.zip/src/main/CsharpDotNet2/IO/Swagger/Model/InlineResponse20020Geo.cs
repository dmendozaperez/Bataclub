using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20020Geo {
    /// <summary>
    /// Gets or Sets CountryISOCode
    /// </summary>
    [DataMember(Name="CountryISOCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "CountryISOCode")]
    public string CountryISOCode { get; set; }

    /// <summary>
    /// Gets or Sets Country
    /// </summary>
    [DataMember(Name="Country", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Country")]
    public string Country { get; set; }

    /// <summary>
    /// Gets or Sets RegionISOCode
    /// </summary>
    [DataMember(Name="RegionISOCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "RegionISOCode")]
    public string RegionISOCode { get; set; }

    /// <summary>
    /// Gets or Sets City
    /// </summary>
    [DataMember(Name="City", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "City")]
    public string City { get; set; }

    /// <summary>
    /// Gets or Sets Zip
    /// </summary>
    [DataMember(Name="Zip", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Zip")]
    public string Zip { get; set; }

    /// <summary>
    /// Gets or Sets Coords
    /// </summary>
    [DataMember(Name="Coords", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Coords")]
    public string Coords { get; set; }

    /// <summary>
    /// Gets or Sets IP
    /// </summary>
    [DataMember(Name="IP", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "IP")]
    public string IP { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20020Geo {\n");
      sb.Append("  CountryISOCode: ").Append(CountryISOCode).Append("\n");
      sb.Append("  Country: ").Append(Country).Append("\n");
      sb.Append("  RegionISOCode: ").Append(RegionISOCode).Append("\n");
      sb.Append("  City: ").Append(City).Append("\n");
      sb.Append("  Zip: ").Append(Zip).Append("\n");
      sb.Append("  Coords: ").Append(Coords).Append("\n");
      sb.Append("  IP: ").Append(IP).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
