using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20022Clicks {
    /// <summary>
    /// Gets or Sets ClickLocation
    /// </summary>
    [DataMember(Name="ClickLocation", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ClickLocation")]
    public string ClickLocation { get; set; }

    /// <summary>
    /// Gets or Sets _Client
    /// </summary>
    [DataMember(Name="Client", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Client")]
    public List<InlineResponse20020Client> _Client { get; set; }

    /// <summary>
    /// Gets or Sets OS
    /// </summary>
    [DataMember(Name="OS", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "OS")]
    public List<InlineResponse20020OS> OS { get; set; }

    /// <summary>
    /// Gets or Sets Platform
    /// </summary>
    [DataMember(Name="Platform", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Platform")]
    public string Platform { get; set; }

    /// <summary>
    /// Gets or Sets UserAgent
    /// </summary>
    [DataMember(Name="UserAgent", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "UserAgent")]
    public string UserAgent { get; set; }

    /// <summary>
    /// Gets or Sets OriginalLink
    /// </summary>
    [DataMember(Name="OriginalLink", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "OriginalLink")]
    public string OriginalLink { get; set; }

    /// <summary>
    /// Gets or Sets Geo
    /// </summary>
    [DataMember(Name="Geo", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Geo")]
    public List<InlineResponse20020Geo> Geo { get; set; }

    /// <summary>
    /// Gets or Sets MessageID
    /// </summary>
    [DataMember(Name="MessageID", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "MessageID")]
    public string MessageID { get; set; }

    /// <summary>
    /// Gets or Sets ReceivedAt
    /// </summary>
    [DataMember(Name="ReceivedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ReceivedAt")]
    public string ReceivedAt { get; set; }

    /// <summary>
    /// Gets or Sets Tag
    /// </summary>
    [DataMember(Name="Tag", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Tag")]
    public string Tag { get; set; }

    /// <summary>
    /// Gets or Sets Recipient
    /// </summary>
    [DataMember(Name="Recipient", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Recipient")]
    public string Recipient { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20022Clicks {\n");
      sb.Append("  ClickLocation: ").Append(ClickLocation).Append("\n");
      sb.Append("  _Client: ").Append(_Client).Append("\n");
      sb.Append("  OS: ").Append(OS).Append("\n");
      sb.Append("  Platform: ").Append(Platform).Append("\n");
      sb.Append("  UserAgent: ").Append(UserAgent).Append("\n");
      sb.Append("  OriginalLink: ").Append(OriginalLink).Append("\n");
      sb.Append("  Geo: ").Append(Geo).Append("\n");
      sb.Append("  MessageID: ").Append(MessageID).Append("\n");
      sb.Append("  ReceivedAt: ").Append(ReceivedAt).Append("\n");
      sb.Append("  Tag: ").Append(Tag).Append("\n");
      sb.Append("  Recipient: ").Append(Recipient).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
