using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20011SuggestedTemplateModel {
    /// <summary>
    /// Gets or Sets UserName
    /// </summary>
    [DataMember(Name="userName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userName")]
    public string UserName { get; set; }

    /// <summary>
    /// Gets or Sets Company
    /// </summary>
    [DataMember(Name="company", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "company")]
    public List<InlineResponse20011Company> Company { get; set; }

    /// <summary>
    /// Gets or Sets Person
    /// </summary>
    [DataMember(Name="person", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "person")]
    public List<InlineResponse20011Person> Person { get; set; }

    /// <summary>
    /// Gets or Sets SubjectHeadline
    /// </summary>
    [DataMember(Name="subjectHeadline", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "subjectHeadline")]
    public string SubjectHeadline { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20011SuggestedTemplateModel {\n");
      sb.Append("  UserName: ").Append(UserName).Append("\n");
      sb.Append("  Company: ").Append(Company).Append("\n");
      sb.Append("  Person: ").Append(Person).Append("\n");
      sb.Append("  SubjectHeadline: ").Append(SubjectHeadline).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
