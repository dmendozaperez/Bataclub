using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20035 {
    /// <summary>
    /// Gets or Sets Days
    /// </summary>
    [DataMember(Name="Days", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Days")]
    public List<InlineResponse20035Days> Days { get; set; }

    /// <summary>
    /// Gets or Sets HTML
    /// </summary>
    [DataMember(Name="HTML", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "HTML")]
    public int? HTML { get; set; }

    /// <summary>
    /// Gets or Sets Text
    /// </summary>
    [DataMember(Name="Text", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Text")]
    public int? Text { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20035 {\n");
      sb.Append("  Days: ").Append(Days).Append("\n");
      sb.Append("  HTML: ").Append(HTML).Append("\n");
      sb.Append("  Text: ").Append(Text).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
