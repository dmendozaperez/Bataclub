using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// Create a template
  /// </summary>
  [DataContract]
  public class CreateTemplate {
    /// <summary>
    /// Name of template.
    /// </summary>
    /// <value>Name of template.</value>
    [DataMember(Name="Name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Name")]
    public string Name { get; set; }

    /// <summary>
    /// The content to use for the Subject when this template is used to send email. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.
    /// </summary>
    /// <value>The content to use for the Subject when this template is used to send email. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.</value>
    [DataMember(Name="Subject", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Subject")]
    public string Subject { get; set; }

    /// <summary>
    /// The content to use for the HtmlBody when this template is used to send email. Required if TextBody is not specified. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.
    /// </summary>
    /// <value>The content to use for the HtmlBody when this template is used to send email. Required if TextBody is not specified. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.</value>
    [DataMember(Name="TextBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TextBody")]
    public string TextBody { get; set; }

    /// <summary>
    /// The content to use for the TextBody when this template is used to send email. Required if HtmlBody is not specified. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.
    /// </summary>
    /// <value>The content to use for the TextBody when this template is used to send email. Required if HtmlBody is not specified. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.</value>
    [DataMember(Name="HtmlBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "HtmlBody")]
    public string HtmlBody { get; set; }

    /// <summary>
    /// An optional string you can provide to identify this Template. Allowed characters are numbers, ASCII letters, and ‘.’, ‘-’, ‘_’ characters, and the string has to start with a letter.
    /// </summary>
    /// <value>An optional string you can provide to identify this Template. Allowed characters are numbers, ASCII letters, and ‘.’, ‘-’, ‘_’ characters, and the string has to start with a letter.</value>
    [DataMember(Name="Alias", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Alias")]
    public string Alias { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class CreateTemplate {\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Subject: ").Append(Subject).Append("\n");
      sb.Append("  TextBody: ").Append(TextBody).Append("\n");
      sb.Append("  HtmlBody: ").Append(HtmlBody).Append("\n");
      sb.Append("  Alias: ").Append(Alias).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
