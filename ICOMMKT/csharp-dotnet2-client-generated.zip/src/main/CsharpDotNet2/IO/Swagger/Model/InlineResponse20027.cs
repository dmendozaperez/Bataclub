using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20027 {
    /// <summary>
    /// Gets or Sets Days
    /// </summary>
    [DataMember(Name="Days", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Days")]
    public List<InlineResponse20027Days> Days { get; set; }

    /// <summary>
    /// Gets or Sets Tracked
    /// </summary>
    [DataMember(Name="Tracked", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Tracked")]
    public int? Tracked { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20027 {\n");
      sb.Append("  Days: ").Append(Days).Append("\n");
      sb.Append("  Tracked: ").Append(Tracked).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
