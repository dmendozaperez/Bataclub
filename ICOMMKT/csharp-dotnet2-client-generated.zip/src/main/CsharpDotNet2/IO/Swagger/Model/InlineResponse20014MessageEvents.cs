using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20014MessageEvents {
    /// <summary>
    /// Gets or Sets Recipient
    /// </summary>
    [DataMember(Name="Recipient", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Recipient")]
    public string Recipient { get; set; }

    /// <summary>
    /// Gets or Sets Type
    /// </summary>
    [DataMember(Name="Type", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Type")]
    public string Type { get; set; }

    /// <summary>
    /// Gets or Sets ReceivedAt
    /// </summary>
    [DataMember(Name="ReceivedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ReceivedAt")]
    public string ReceivedAt { get; set; }

    /// <summary>
    /// Gets or Sets Details
    /// </summary>
    [DataMember(Name="Details", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Details")]
    public List<InlineResponse20014Details> Details { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20014MessageEvents {\n");
      sb.Append("  Recipient: ").Append(Recipient).Append("\n");
      sb.Append("  Type: ").Append(Type).Append("\n");
      sb.Append("  ReceivedAt: ").Append(ReceivedAt).Append("\n");
      sb.Append("  Details: ").Append(Details).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
