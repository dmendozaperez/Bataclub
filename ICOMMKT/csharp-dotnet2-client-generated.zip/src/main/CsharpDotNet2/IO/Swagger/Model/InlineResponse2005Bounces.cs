using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse2005Bounces {
    /// <summary>
    /// Gets or Sets ID
    /// </summary>
    [DataMember(Name="ID", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ID")]
    public string ID { get; set; }

    /// <summary>
    /// Gets or Sets Type
    /// </summary>
    [DataMember(Name="Type", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Type")]
    public string Type { get; set; }

    /// <summary>
    /// Gets or Sets TypeCode
    /// </summary>
    [DataMember(Name="TypeCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TypeCode")]
    public int? TypeCode { get; set; }

    /// <summary>
    /// Gets or Sets Name
    /// </summary>
    [DataMember(Name="Name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Name")]
    public string Name { get; set; }

    /// <summary>
    /// Gets or Sets Tag
    /// </summary>
    [DataMember(Name="Tag", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Tag")]
    public string Tag { get; set; }

    /// <summary>
    /// Gets or Sets MessageID
    /// </summary>
    [DataMember(Name="MessageID", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "MessageID")]
    public string MessageID { get; set; }

    /// <summary>
    /// Gets or Sets ServerID
    /// </summary>
    [DataMember(Name="ServerID", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ServerID")]
    public string ServerID { get; set; }

    /// <summary>
    /// Gets or Sets Description
    /// </summary>
    [DataMember(Name="Description", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Description")]
    public string Description { get; set; }

    /// <summary>
    /// Gets or Sets Details
    /// </summary>
    [DataMember(Name="Details", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Details")]
    public string Details { get; set; }

    /// <summary>
    /// Gets or Sets Email
    /// </summary>
    [DataMember(Name="Email", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Email")]
    public string Email { get; set; }

    /// <summary>
    /// Gets or Sets From
    /// </summary>
    [DataMember(Name="From", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "From")]
    public string From { get; set; }

    /// <summary>
    /// Gets or Sets BouncedAt
    /// </summary>
    [DataMember(Name="BouncedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "BouncedAt")]
    public string BouncedAt { get; set; }

    /// <summary>
    /// Gets or Sets DumpAvailable
    /// </summary>
    [DataMember(Name="DumpAvailable", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DumpAvailable")]
    public bool? DumpAvailable { get; set; }

    /// <summary>
    /// Gets or Sets Inactive
    /// </summary>
    [DataMember(Name="Inactive", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Inactive")]
    public bool? Inactive { get; set; }

    /// <summary>
    /// Gets or Sets CanActivate
    /// </summary>
    [DataMember(Name="CanActivate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "CanActivate")]
    public bool? CanActivate { get; set; }

    /// <summary>
    /// Gets or Sets Subject
    /// </summary>
    [DataMember(Name="Subject", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Subject")]
    public string Subject { get; set; }

    /// <summary>
    /// Gets or Sets Content
    /// </summary>
    [DataMember(Name="Content", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Content")]
    public string Content { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse2005Bounces {\n");
      sb.Append("  ID: ").Append(ID).Append("\n");
      sb.Append("  Type: ").Append(Type).Append("\n");
      sb.Append("  TypeCode: ").Append(TypeCode).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Tag: ").Append(Tag).Append("\n");
      sb.Append("  MessageID: ").Append(MessageID).Append("\n");
      sb.Append("  ServerID: ").Append(ServerID).Append("\n");
      sb.Append("  Description: ").Append(Description).Append("\n");
      sb.Append("  Details: ").Append(Details).Append("\n");
      sb.Append("  Email: ").Append(Email).Append("\n");
      sb.Append("  From: ").Append(From).Append("\n");
      sb.Append("  BouncedAt: ").Append(BouncedAt).Append("\n");
      sb.Append("  DumpAvailable: ").Append(DumpAvailable).Append("\n");
      sb.Append("  Inactive: ").Append(Inactive).Append("\n");
      sb.Append("  CanActivate: ").Append(CanActivate).Append("\n");
      sb.Append("  Subject: ").Append(Subject).Append("\n");
      sb.Append("  Content: ").Append(Content).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
