using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20023 {
    /// <summary>
    /// Gets or Sets BounceRate
    /// </summary>
    [DataMember(Name="BounceRate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "BounceRate")]
    public int? BounceRate { get; set; }

    /// <summary>
    /// Gets or Sets Bounced
    /// </summary>
    [DataMember(Name="Bounced", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Bounced")]
    public int? Bounced { get; set; }

    /// <summary>
    /// Gets or Sets Opens
    /// </summary>
    [DataMember(Name="Opens", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Opens")]
    public int? Opens { get; set; }

    /// <summary>
    /// Gets or Sets SMTPApiErrors
    /// </summary>
    [DataMember(Name="SMTPApiErrors", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "SMTPApiErrors")]
    public int? SMTPApiErrors { get; set; }

    /// <summary>
    /// Gets or Sets Sent
    /// </summary>
    [DataMember(Name="Sent", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Sent")]
    public int? Sent { get; set; }

    /// <summary>
    /// Gets or Sets SpamComplaints
    /// </summary>
    [DataMember(Name="SpamComplaints", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "SpamComplaints")]
    public int? SpamComplaints { get; set; }

    /// <summary>
    /// Gets or Sets SpamComplaintsRate
    /// </summary>
    [DataMember(Name="SpamComplaintsRate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "SpamComplaintsRate")]
    public int? SpamComplaintsRate { get; set; }

    /// <summary>
    /// Gets or Sets TotalClicks
    /// </summary>
    [DataMember(Name="TotalClicks", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TotalClicks")]
    public int? TotalClicks { get; set; }

    /// <summary>
    /// Gets or Sets TotalTrackedLinksSent
    /// </summary>
    [DataMember(Name="TotalTrackedLinksSent", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TotalTrackedLinksSent")]
    public int? TotalTrackedLinksSent { get; set; }

    /// <summary>
    /// Gets or Sets Tracked
    /// </summary>
    [DataMember(Name="Tracked", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Tracked")]
    public int? Tracked { get; set; }

    /// <summary>
    /// Gets or Sets UniqueLinksClicked
    /// </summary>
    [DataMember(Name="UniqueLinksClicked", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "UniqueLinksClicked")]
    public int? UniqueLinksClicked { get; set; }

    /// <summary>
    /// Gets or Sets UniqueOpens
    /// </summary>
    [DataMember(Name="UniqueOpens", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "UniqueOpens")]
    public int? UniqueOpens { get; set; }

    /// <summary>
    /// Gets or Sets WithClientRecorded
    /// </summary>
    [DataMember(Name="WithClientRecorded", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "WithClientRecorded")]
    public int? WithClientRecorded { get; set; }

    /// <summary>
    /// Gets or Sets WithLinkTracking
    /// </summary>
    [DataMember(Name="WithLinkTracking", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "WithLinkTracking")]
    public int? WithLinkTracking { get; set; }

    /// <summary>
    /// Gets or Sets WithOpenTracking
    /// </summary>
    [DataMember(Name="WithOpenTracking", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "WithOpenTracking")]
    public int? WithOpenTracking { get; set; }

    /// <summary>
    /// Gets or Sets WithPlatformRecorded
    /// </summary>
    [DataMember(Name="WithPlatformRecorded", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "WithPlatformRecorded")]
    public int? WithPlatformRecorded { get; set; }

    /// <summary>
    /// Gets or Sets WithReadTimeRecorded
    /// </summary>
    [DataMember(Name="WithReadTimeRecorded", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "WithReadTimeRecorded")]
    public int? WithReadTimeRecorded { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20023 {\n");
      sb.Append("  BounceRate: ").Append(BounceRate).Append("\n");
      sb.Append("  Bounced: ").Append(Bounced).Append("\n");
      sb.Append("  Opens: ").Append(Opens).Append("\n");
      sb.Append("  SMTPApiErrors: ").Append(SMTPApiErrors).Append("\n");
      sb.Append("  Sent: ").Append(Sent).Append("\n");
      sb.Append("  SpamComplaints: ").Append(SpamComplaints).Append("\n");
      sb.Append("  SpamComplaintsRate: ").Append(SpamComplaintsRate).Append("\n");
      sb.Append("  TotalClicks: ").Append(TotalClicks).Append("\n");
      sb.Append("  TotalTrackedLinksSent: ").Append(TotalTrackedLinksSent).Append("\n");
      sb.Append("  Tracked: ").Append(Tracked).Append("\n");
      sb.Append("  UniqueLinksClicked: ").Append(UniqueLinksClicked).Append("\n");
      sb.Append("  UniqueOpens: ").Append(UniqueOpens).Append("\n");
      sb.Append("  WithClientRecorded: ").Append(WithClientRecorded).Append("\n");
      sb.Append("  WithLinkTracking: ").Append(WithLinkTracking).Append("\n");
      sb.Append("  WithOpenTracking: ").Append(WithOpenTracking).Append("\n");
      sb.Append("  WithPlatformRecorded: ").Append(WithPlatformRecorded).Append("\n");
      sb.Append("  WithReadTimeRecorded: ").Append(WithReadTimeRecorded).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
