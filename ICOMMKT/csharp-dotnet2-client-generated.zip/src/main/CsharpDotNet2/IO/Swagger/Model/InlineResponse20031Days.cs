using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20031Days {
    /// <summary>
    /// Gets or Sets Date
    /// </summary>
    [DataMember(Name="Date", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Date")]
    public string Date { get; set; }

    /// <summary>
    /// Gets or Sets _3s
    /// </summary>
    [DataMember(Name="3s", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "3s")]
    public int? _3s { get; set; }

    /// <summary>
    /// Gets or Sets _7s
    /// </summary>
    [DataMember(Name="7s", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "7s")]
    public int? _7s { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20031Days {\n");
      sb.Append("  Date: ").Append(Date).Append("\n");
      sb.Append("  _3s: ").Append(_3s).Append("\n");
      sb.Append("  _7s: ").Append(_7s).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
