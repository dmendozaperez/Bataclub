using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// Email object
  /// </summary>
  [DataContract]
  public class BatchEmail {
    /// <summary>
    /// The sender email address. Must have a registered and confirmed Sender Signature.
    /// </summary>
    /// <value>The sender email address. Must have a registered and confirmed Sender Signature.</value>
    [DataMember(Name="From", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "From")]
    public string From { get; set; }

    /// <summary>
    /// Recipient email address. Multiple addresses are comma separated.
    /// </summary>
    /// <value>Recipient email address. Multiple addresses are comma separated.</value>
    [DataMember(Name="To", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "To")]
    public string To { get; set; }

    /// <summary>
    /// Cc recipient email address. Multiple addresses are comma separated.
    /// </summary>
    /// <value>Cc recipient email address. Multiple addresses are comma separated.</value>
    [DataMember(Name="Cc", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Cc")]
    public string Cc { get; set; }

    /// <summary>
    /// Bcc recipient email address. Multiple addresses are comma separated.
    /// </summary>
    /// <value>Bcc recipient email address. Multiple addresses are comma separated.</value>
    [DataMember(Name="Bcc", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Bcc")]
    public string Bcc { get; set; }

    /// <summary>
    /// Email subject.
    /// </summary>
    /// <value>Email subject.</value>
    [DataMember(Name="Subject", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Subject")]
    public string Subject { get; set; }

    /// <summary>
    /// Email tag that allows you to categorize outgoing emails and get detailed statistics.
    /// </summary>
    /// <value>Email tag that allows you to categorize outgoing emails and get detailed statistics.</value>
    [DataMember(Name="Tag", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Tag")]
    public string Tag { get; set; }

    /// <summary>
    /// If TextBody is not specified HTML email message
    /// </summary>
    /// <value>If TextBody is not specified HTML email message</value>
    [DataMember(Name="HtmlBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "HtmlBody")]
    public string HtmlBody { get; set; }

    /// <summary>
    /// If HtmlBody is not specified Plain text email message.
    /// </summary>
    /// <value>If HtmlBody is not specified Plain text email message.</value>
    [DataMember(Name="TextBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TextBody")]
    public string TextBody { get; set; }

    /// <summary>
    /// Reply To override email address. Defaults to the Reply To set in the sender signature.
    /// </summary>
    /// <value>Reply To override email address. Defaults to the Reply To set in the sender signature.</value>
    [DataMember(Name="ReplyTo", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ReplyTo")]
    public string ReplyTo { get; set; }

    /// <summary>
    /// List of custom headers to include.
    /// </summary>
    /// <value>List of custom headers to include.</value>
    [DataMember(Name="Headers", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Headers")]
    public string Headers { get; set; }

    /// <summary>
    /// Activate open tracking for this email.
    /// </summary>
    /// <value>Activate open tracking for this email.</value>
    [DataMember(Name="TrackOpens", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TrackOpens")]
    public bool? TrackOpens { get; set; }

    /// <summary>
    /// Activate link tracking for links in the HTML or Text bodies of this email. Possible options None HtmlAndText HtmlOnly TextOnly.
    /// </summary>
    /// <value>Activate link tracking for links in the HTML or Text bodies of this email. Possible options None HtmlAndText HtmlOnly TextOnly.</value>
    [DataMember(Name="TrackLinks", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TrackLinks")]
    public string TrackLinks { get; set; }

    /// <summary>
    /// List of attachments
    /// </summary>
    /// <value>List of attachments</value>
    [DataMember(Name="Attachments", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Attachments")]
    public List<> Attachments { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class BatchEmail {\n");
      sb.Append("  From: ").Append(From).Append("\n");
      sb.Append("  To: ").Append(To).Append("\n");
      sb.Append("  Cc: ").Append(Cc).Append("\n");
      sb.Append("  Bcc: ").Append(Bcc).Append("\n");
      sb.Append("  Subject: ").Append(Subject).Append("\n");
      sb.Append("  Tag: ").Append(Tag).Append("\n");
      sb.Append("  HtmlBody: ").Append(HtmlBody).Append("\n");
      sb.Append("  TextBody: ").Append(TextBody).Append("\n");
      sb.Append("  ReplyTo: ").Append(ReplyTo).Append("\n");
      sb.Append("  Headers: ").Append(Headers).Append("\n");
      sb.Append("  TrackOpens: ").Append(TrackOpens).Append("\n");
      sb.Append("  TrackLinks: ").Append(TrackLinks).Append("\n");
      sb.Append("  Attachments: ").Append(Attachments).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
