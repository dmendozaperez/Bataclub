using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// Validate a template
  /// </summary>
  [DataContract]
  public class ValidateTemplate {
    /// <summary>
    /// The subject content to validate. Must be specified if HtmlBody or TextBody are not. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.
    /// </summary>
    /// <value>The subject content to validate. Must be specified if HtmlBody or TextBody are not. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.</value>
    [DataMember(Name="Subject", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Subject")]
    public string Subject { get; set; }

    /// <summary>
    /// The html body content to validate. Must be specified if Subject or TextBody are not. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.
    /// </summary>
    /// <value>The html body content to validate. Must be specified if Subject or TextBody are not. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.</value>
    [DataMember(Name="TextBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TextBody")]
    public string TextBody { get; set; }

    /// <summary>
    /// The text body content to validate. Must be specified if HtmlBody or Subject are not. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.
    /// </summary>
    /// <value>The text body content to validate. Must be specified if HtmlBody or Subject are not. See our <a href=\"http://support.postmarkapp.com/article/1077-template-syntax\">template language documentation</a> for more information on the syntax for this field.</value>
    [DataMember(Name="HtmlBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "HtmlBody")]
    public string HtmlBody { get; set; }

    /// <summary>
    /// The model to be used when rendering test content.
    /// </summary>
    /// <value>The model to be used when rendering test content.</value>
    [DataMember(Name="TestRenderModel", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TestRenderModel")]
    public string TestRenderModel { get; set; }

    /// <summary>
    /// When HtmlBody is specified, the test render will have style blocks inlined as style attributes on matching html elements. You may disable the css inlining behavior by passing false for this parameter.
    /// </summary>
    /// <value>When HtmlBody is specified, the test render will have style blocks inlined as style attributes on matching html elements. You may disable the css inlining behavior by passing false for this parameter.</value>
    [DataMember(Name="InlineCssForHtmlTestRender", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "InlineCssForHtmlTestRender")]
    public string InlineCssForHtmlTestRender { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ValidateTemplate {\n");
      sb.Append("  Subject: ").Append(Subject).Append("\n");
      sb.Append("  TextBody: ").Append(TextBody).Append("\n");
      sb.Append("  HtmlBody: ").Append(HtmlBody).Append("\n");
      sb.Append("  TestRenderModel: ").Append(TestRenderModel).Append("\n");
      sb.Append("  InlineCssForHtmlTestRender: ").Append(InlineCssForHtmlTestRender).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
