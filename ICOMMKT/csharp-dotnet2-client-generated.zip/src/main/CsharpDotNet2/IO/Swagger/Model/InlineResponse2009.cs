using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse2009 {
    /// <summary>
    /// Gets or Sets Active
    /// </summary>
    [DataMember(Name="Active", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Active")]
    public bool? Active { get; set; }

    /// <summary>
    /// Gets or Sets Alias
    /// </summary>
    [DataMember(Name="Alias", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Alias")]
    public string Alias { get; set; }

    /// <summary>
    /// Gets or Sets AssociatedServerId
    /// </summary>
    [DataMember(Name="AssociatedServerId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "AssociatedServerId")]
    public string AssociatedServerId { get; set; }

    /// <summary>
    /// Gets or Sets HtmlBody
    /// </summary>
    [DataMember(Name="HtmlBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "HtmlBody")]
    public string HtmlBody { get; set; }

    /// <summary>
    /// Gets or Sets Name
    /// </summary>
    [DataMember(Name="Name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Name")]
    public string Name { get; set; }

    /// <summary>
    /// Gets or Sets Subject
    /// </summary>
    [DataMember(Name="Subject", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Subject")]
    public string Subject { get; set; }

    /// <summary>
    /// Gets or Sets TemplateId
    /// </summary>
    [DataMember(Name="TemplateId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TemplateId")]
    public int? TemplateId { get; set; }

    /// <summary>
    /// Gets or Sets TextBody
    /// </summary>
    [DataMember(Name="TextBody", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TextBody")]
    public string TextBody { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse2009 {\n");
      sb.Append("  Active: ").Append(Active).Append("\n");
      sb.Append("  Alias: ").Append(Alias).Append("\n");
      sb.Append("  AssociatedServerId: ").Append(AssociatedServerId).Append("\n");
      sb.Append("  HtmlBody: ").Append(HtmlBody).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Subject: ").Append(Subject).Append("\n");
      sb.Append("  TemplateId: ").Append(TemplateId).Append("\n");
      sb.Append("  TextBody: ").Append(TextBody).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
