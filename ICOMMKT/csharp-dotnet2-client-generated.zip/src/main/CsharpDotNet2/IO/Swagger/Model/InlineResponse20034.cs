using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20034 {
    /// <summary>
    /// Gets or Sets Days
    /// </summary>
    [DataMember(Name="Days", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Days")]
    public List<InlineResponse20034Days> Days { get; set; }

    /// <summary>
    /// Gets or Sets Desktop
    /// </summary>
    [DataMember(Name="Desktop", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Desktop")]
    public int? Desktop { get; set; }

    /// <summary>
    /// Gets or Sets Mobile
    /// </summary>
    [DataMember(Name="Mobile", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Mobile")]
    public int? Mobile { get; set; }

    /// <summary>
    /// Gets or Sets Unknown
    /// </summary>
    [DataMember(Name="Unknown", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Unknown")]
    public int? Unknown { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20034 {\n");
      sb.Append("  Days: ").Append(Days).Append("\n");
      sb.Append("  Desktop: ").Append(Desktop).Append("\n");
      sb.Append("  Mobile: ").Append(Mobile).Append("\n");
      sb.Append("  Unknown: ").Append(Unknown).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
