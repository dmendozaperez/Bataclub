using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20011ValidationErrors {
    /// <summary>
    /// Gets or Sets Message
    /// </summary>
    [DataMember(Name="Message", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Message")]
    public string Message { get; set; }

    /// <summary>
    /// Gets or Sets Line
    /// </summary>
    [DataMember(Name="Line", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Line")]
    public int? Line { get; set; }

    /// <summary>
    /// Gets or Sets CharacterPosition
    /// </summary>
    [DataMember(Name="CharacterPosition", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "CharacterPosition")]
    public int? CharacterPosition { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20011ValidationErrors {\n");
      sb.Append("  Message: ").Append(Message).Append("\n");
      sb.Append("  Line: ").Append(Line).Append("\n");
      sb.Append("  CharacterPosition: ").Append(CharacterPosition).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
