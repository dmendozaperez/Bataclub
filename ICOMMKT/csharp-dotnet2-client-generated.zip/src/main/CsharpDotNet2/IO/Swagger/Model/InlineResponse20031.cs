using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InlineResponse20031 {
    /// <summary>
    /// Gets or Sets _10s
    /// </summary>
    [DataMember(Name="10s", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "10s")]
    public int? _10s { get; set; }

    /// <summary>
    /// Gets or Sets _1s
    /// </summary>
    [DataMember(Name="1s", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "1s")]
    public int? _1s { get; set; }

    /// <summary>
    /// Gets or Sets _20s
    /// </summary>
    [DataMember(Name="20s+", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "20s+")]
    public int? _20s { get; set; }

    /// <summary>
    /// Gets or Sets _3s
    /// </summary>
    [DataMember(Name="3s", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "3s")]
    public int? _3s { get; set; }

    /// <summary>
    /// Gets or Sets _7s
    /// </summary>
    [DataMember(Name="7s", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "7s")]
    public int? _7s { get; set; }

    /// <summary>
    /// Gets or Sets _8s
    /// </summary>
    [DataMember(Name="8s", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "8s")]
    public int? _8s { get; set; }

    /// <summary>
    /// Gets or Sets Days
    /// </summary>
    [DataMember(Name="Days", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Days")]
    public List<InlineResponse20031Days> Days { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InlineResponse20031 {\n");
      sb.Append("  _10s: ").Append(_10s).Append("\n");
      sb.Append("  _1s: ").Append(_1s).Append("\n");
      sb.Append("  _20s: ").Append(_20s).Append("\n");
      sb.Append("  _3s: ").Append(_3s).Append("\n");
      sb.Append("  _7s: ").Append(_7s).Append("\n");
      sb.Append("  _8s: ").Append(_8s).Append("\n");
      sb.Append("  Days: ").Append(Days).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
