# IO.Swagger.Model.InlineResponse20025
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List&lt;InlineResponse20025Days&gt;**](InlineResponse20025Days.md) |  | [optional] 
**HardBounce** | **int?** |  | [optional] 
**SMTPApiError** | **int?** |  | [optional] 
**SoftBounce** | **int?** |  | [optional] 
**Transient** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

