# IO.Swagger.Model.InlineResponse20023
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BounceRate** | **int?** |  | [optional] 
**Bounced** | **int?** |  | [optional] 
**Opens** | **int?** |  | [optional] 
**SMTPApiErrors** | **int?** |  | [optional] 
**Sent** | **int?** |  | [optional] 
**SpamComplaints** | **int?** |  | [optional] 
**SpamComplaintsRate** | **int?** |  | [optional] 
**TotalClicks** | **int?** |  | [optional] 
**TotalTrackedLinksSent** | **int?** |  | [optional] 
**Tracked** | **int?** |  | [optional] 
**UniqueLinksClicked** | **int?** |  | [optional] 
**UniqueOpens** | **int?** |  | [optional] 
**WithClientRecorded** | **int?** |  | [optional] 
**WithLinkTracking** | **int?** |  | [optional] 
**WithOpenTracking** | **int?** |  | [optional] 
**WithPlatformRecorded** | **int?** |  | [optional] 
**WithReadTimeRecorded** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

