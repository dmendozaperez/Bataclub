# IO.Swagger.Model.InlineResponse20021Opens
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Client** | [**List&lt;InlineResponse20020Client&gt;**](InlineResponse20020Client.md) |  | [optional] 
**OS** | [**List&lt;InlineResponse20020OS&gt;**](InlineResponse20020OS.md) |  | [optional] 
**Platform** | **string** |  | [optional] 
**UserAgent** | **string** |  | [optional] 
**ReadSeconds** | **int?** |  | [optional] 
**Geo** | [**List&lt;InlineResponse20020Geo&gt;**](InlineResponse20020Geo.md) |  | [optional] 
**MessageID** | **string** |  | [optional] 
**ReceivedAt** | **string** |  | [optional] 
**Tag** | **string** |  | [optional] 
**Recipient** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

