# IO.Swagger.Model.InlineResponse20028
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List&lt;InlineResponse20028Days&gt;**](InlineResponse20028Days.md) |  | [optional] 
**Opens** | **int?** |  | [optional] 
**Unique** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

