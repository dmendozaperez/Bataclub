# IO.Swagger.Model.InlineResponse20026
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List&lt;InlineResponse20026Days&gt;**](InlineResponse20026Days.md) |  | [optional] 
**SpamComplaint** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

