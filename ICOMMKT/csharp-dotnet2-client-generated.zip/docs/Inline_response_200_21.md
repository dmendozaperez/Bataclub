# IO.Swagger.Model.InlineResponse20021
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Opens** | [**List&lt;InlineResponse20021Opens&gt;**](InlineResponse20021Opens.md) |  | [optional] 
**TotalCount** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

