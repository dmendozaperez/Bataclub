# IO.Swagger.Model.InlineResponse20034
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List&lt;InlineResponse20034Days&gt;**](InlineResponse20034Days.md) |  | [optional] 
**Desktop** | **int?** |  | [optional] 
**Mobile** | **int?** |  | [optional] 
**Unknown** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

