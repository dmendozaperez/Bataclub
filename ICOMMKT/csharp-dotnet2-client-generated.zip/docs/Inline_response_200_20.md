# IO.Swagger.Model.InlineResponse20020
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Opens** | [**List&lt;InlineResponse20020Opens&gt;**](InlineResponse20020Opens.md) |  | [optional] 
**TotalCount** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

