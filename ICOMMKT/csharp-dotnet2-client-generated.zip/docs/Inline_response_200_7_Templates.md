# IO.Swagger.Model.InlineResponse2007Templates
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Active** | **bool?** |  | 
**TemplateId** | **int?** |  | 
**Name** | **string** |  | 
**Alias** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

