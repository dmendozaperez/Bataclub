# IO.Swagger.Model.InlineResponse20037
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **int?** |  | [optional] 
**MatchName** | **string** |  | [optional] 
**TrackOpens** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

