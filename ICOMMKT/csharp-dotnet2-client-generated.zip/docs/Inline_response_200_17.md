# IO.Swagger.Model.InlineResponse20017
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Attachments** | [**List&lt;InlineResponse20016Attachments&gt;**](InlineResponse20016Attachments.md) |  | [optional] 
**BlockedReason** | **string** |  | [optional] 
**Cc** | **string** |  | [optional] 
**CcFull** | **string** |  | [optional] 
**Date** | **string** |  | [optional] 
**From** | **string** |  | [optional] 
**FromFull** | [**List&lt;InlineResponse20016FromFull&gt;**](InlineResponse20016FromFull.md) |  | [optional] 
**FromName** | **string** |  | [optional] 
**Headers** | [**List&lt;InlineResponse20017Headers&gt;**](InlineResponse20017Headers.md) |  | [optional] 
**HtmlBody** | **string** |  | [optional] 
**MailboxHash** | **string** |  | [optional] 
**MessageID** | **string** |  | [optional] 
**OriginalRecipient** | **string** |  | [optional] 
**ReplyTo** | **string** |  | [optional] 
**Status** | **string** |  | [optional] 
**Subject** | **string** |  | [optional] 
**Tag** | **string** |  | [optional] 
**TextBody** | **string** |  | [optional] 
**To** | **string** |  | [optional] 
**ToFull** | [**List&lt;InlineResponse20016ToFull&gt;**](InlineResponse20016ToFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

