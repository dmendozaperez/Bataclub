# IO.Swagger.Model.CreateTriggerForTag
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MatchName** | **string** | Name of the tag that will activate this trigger. | [optional] 
**TrackOpens** | **bool?** | Indicates if this trigger activates open tracking. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

