# IO.Swagger.Model.InlineResponse20016InboundMessages
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**From** | **string** |  | [optional] 
**FromName** | **string** |  | [optional] 
**FromFull** | [**List&lt;InlineResponse20016FromFull&gt;**](InlineResponse20016FromFull.md) |  | [optional] 
**To** | **string** |  | [optional] 
**ToFull** | [**List&lt;InlineResponse20016ToFull&gt;**](InlineResponse20016ToFull.md) |  | [optional] 
**CcFull** | [**List&lt;&gt;**](.md) |  | [optional] 
**Cc** | **string** |  | [optional] 
**ReplyTo** | **string** |  | [optional] 
**OriginalRecipient** | **string** |  | [optional] 
**Subject** | **string** |  | [optional] 
**Date** | **string** |  | [optional] 
**MailboxHash** | **string** |  | [optional] 
**Tag** | **string** |  | [optional] 
**Attachments** | [**List&lt;InlineResponse20016Attachments&gt;**](InlineResponse20016Attachments.md) |  | [optional] 
**MessageID** | **string** |  | [optional] 
**Status** | **string** |  | [optional] 
**TrackLinks** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

