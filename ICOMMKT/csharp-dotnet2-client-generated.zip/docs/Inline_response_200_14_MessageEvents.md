# IO.Swagger.Model.InlineResponse20014MessageEvents
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Recipient** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**ReceivedAt** | **string** |  | [optional] 
**Details** | [**List&lt;InlineResponse20014Details&gt;**](InlineResponse20014Details.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

