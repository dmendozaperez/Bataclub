# IO.Swagger.Model.InlineResponse20012
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ErrorCode** | **int?** |  | [optional] 
**Message** | **string** |  | [optional] 
**MessageID** | **string** |  | [optional] 
**SubmittedAt** | **int?** |  | [optional] 
**To** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

