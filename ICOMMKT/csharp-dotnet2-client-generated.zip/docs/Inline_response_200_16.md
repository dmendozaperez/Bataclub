# IO.Swagger.Model.InlineResponse20016
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InboundMessages** | [**List&lt;InlineResponse20016InboundMessages&gt;**](InlineResponse20016InboundMessages.md) |  | [optional] 
**TotalCount** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

