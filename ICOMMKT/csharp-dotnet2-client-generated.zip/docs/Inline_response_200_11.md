# IO.Swagger.Model.InlineResponse20011
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllContentIsValid** | **bool?** |  | [optional] 
**HtmlBody** | [**List&lt;InlineResponse20011HtmlBody&gt;**](InlineResponse20011HtmlBody.md) |  | [optional] 
**Subject** | [**List&lt;InlineResponse20011Subject&gt;**](InlineResponse20011Subject.md) |  | [optional] 
**SuggestedTemplateModel** | [**List&lt;InlineResponse20011SuggestedTemplateModel&gt;**](InlineResponse20011SuggestedTemplateModel.md) |  | [optional] 
**TextBody** | [**List&lt;InlineResponse20011TextBody&gt;**](InlineResponse20011TextBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

