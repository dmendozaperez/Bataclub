# IO.Swagger.Model.InlineResponse20013Messages
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tag** | **string** |  | [optional] 
**MessageID** | **string** |  | [optional] 
**To** | [**List&lt;InlineResponse20013To&gt;**](InlineResponse20013To.md) |  | [optional] 
**Cc** | [**List&lt;&gt;**](.md) |  | [optional] 
**Bcc** | [**List&lt;&gt;**](.md) |  | [optional] 
**Recipients** | **List&lt;Object&gt;** |  | [optional] 
**ReceivedAt** | **string** |  | [optional] 
**From** | **string** |  | [optional] 
**Subject** | **string** |  | [optional] 
**Attachments** | [**List&lt;&gt;**](.md) |  | [optional] 
**Status** | **string** |  | [optional] 
**TrackOpens** | **bool?** |  | [optional] 
**TrackLinks** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

