# IO.Swagger.Model.InlineResponse20029
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Days** | [**List&lt;InlineResponse20029Days&gt;**](InlineResponse20029Days.md) |  | [optional] 
**Desktop** | **int?** |  | [optional] 
**Mobile** | **int?** |  | [optional] 
**Unknown** | **int?** |  | [optional] 
**WebMail** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

