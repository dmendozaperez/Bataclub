# IO.Swagger.Model.InlineResponse2003
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bounces** | [**List&lt;InlineResponse2003Bounces&gt;**](InlineResponse2003Bounces.md) |  | [optional] 
**TotalCount** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

