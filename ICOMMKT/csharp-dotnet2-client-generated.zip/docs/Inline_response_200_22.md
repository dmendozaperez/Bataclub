# IO.Swagger.Model.InlineResponse20022
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Clicks** | [**List&lt;InlineResponse20022Clicks&gt;**](InlineResponse20022Clicks.md) |  | [optional] 
**TotalCount** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

