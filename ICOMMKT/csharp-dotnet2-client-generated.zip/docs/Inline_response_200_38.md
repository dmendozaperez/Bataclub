# IO.Swagger.Model.InlineResponse20038
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MatchName** | **string** |  | [optional] 
**TrackOpens** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

