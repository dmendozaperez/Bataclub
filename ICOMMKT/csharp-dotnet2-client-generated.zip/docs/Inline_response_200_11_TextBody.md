# IO.Swagger.Model.InlineResponse20011TextBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContentIsValid** | **bool?** |  | [optional] 
**ValidationErrors** | [**List&lt;InlineResponse20011ValidationErrors&gt;**](InlineResponse20011ValidationErrors.md) |  | [optional] 
**RenderedContent** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

