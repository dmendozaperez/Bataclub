# IO.Swagger.Model.InlineResponse20032
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Clicks** | **int?** |  | [optional] 
**Days** | [**List&lt;InlineResponse20032Days&gt;**](InlineResponse20032Days.md) |  | [optional] 
**Unique** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

